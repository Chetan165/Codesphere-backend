import os
import sys
import io
import glob

# Store original stdin and stdout to restore them later.
# It is crucial to use sys.__stdin__ and sys.__stdout__ as these are the
# references to the actual original streams, not just variables that might
# hold a reference to a redirected stream.
original_stdin = sys.__stdin__
original_stdout = sys.__stdout__

def execute_solution_code_block():
    """
    This function encapsulates the entire provided solution code block.
    It defines the 'solve' function internally and then proceeds to read
    the number of test cases 'T' and call 'solve' for each.
    It expects sys.stdin and sys.stdout to be redirected prior to its call.
    """

    # --- Start of SOLUTION CODE (pasted directly) ---
    # The 'solve' function from the problem description
    def solve():
        # Read M (rows), N (columns), and target from the first line of the test case.
        # Using sys.stdin.readline() for faster input in competitive programming.
        M, N, target = map(int, sys.stdin.readline().split())

        # Create a single flattened list to store all elements from the matrix.
        flat_list = []
        for _ in range(M):
            # Read each row of the matrix.
            # Each row is already sorted in non-decreasing order, but we need to combine all
            # elements and sort them globally to apply the two-pointer technique efficiently.
            row = list(map(int, sys.stdin.readline().split()))
            # Extend the flat_list with elements from the current row.
            flat_list.extend(row)

        # Sort the flattened list. This is a crucial step for the two-pointer approach.
        # The time complexity for sorting K elements (where K = M * N) is O(K log K).
        flat_list.sort()

        # Initialize two pointers:
        # 'lo' starts at the beginning of the sorted list.
        # 'hi' starts at the end of the sorted list.
        lo, hi = 0, len(flat_list) - 1
        found = False # Flag to track if a pair summing to 'target' is found.

        # Apply the two-pointer technique.
        # The loop continues as long as 'lo' is less than 'hi'. This condition is important
        # because it ensures that we are always considering two distinct elements from
        # the flattened list. Since each element in flat_list corresponds to a unique
        # position in the original matrix, this handles the requirement for 'x' and 'y'
        # to potentially come from distinct matrix indices (r1, c1) != (r2, c2).
        # If a single matrix element `val` appears such that `val + val == target`,
        # this approach correctly finds it only if `val` appears at least twice in the
        # matrix (i.e., at two distinct positions). This aligns with the sample output
        # interpretation (e.g., for target=0, mat=[[0,4],[-5,-1]] leads to "NO", implying 0+0=0 is not allowed).
        while lo < hi:
            current_sum = flat_list[lo] + flat_list[hi]

            if current_sum == target:
                # If the sum of elements at 'lo' and 'hi' equals the target,
                # we have found such a pair.
                found = True
                break # No need to search further, we found a pair.
            elif current_sum < target:
                # If the current sum is less than the target, we need a larger sum.
                # To increase the sum, move the 'lo' pointer forward to consider a larger element.
                lo += 1
            else: # current_sum > target
                # If the current sum is greater than the target, we need a smaller sum.
                # To decrease the sum, move the 'hi' pointer backward to consider a smaller element.
                hi -= 1
        
        # Print the result.
        # Using sys.stdout.write() for faster output.
        if found:
            sys.stdout.write("YES\n")
        else:
            sys.stdout.write("NO\n")

    # Read the total number of test cases.
    T = int(sys.stdin.readline())

    # Iterate through each test case and call the solve function.
    for _ in range(T):
        solve()
    # --- End of SOLUTION CODE ---


# Create the output directory if it doesn't exist.
os.makedirs("output", exist_ok=True)

# Discover all input files in the 'input' directory.
# `glob.glob` is used to find files matching a pattern, and `sorted` ensures
# a consistent order for processing (e.g., input00.txt, input01.txt, etc.).
input_files = sorted(glob.glob("input/input*.txt"))

# Process each input file
for input_filepath in input_files:
    # Extract the base filename and index to construct output file names.
    # Assumes filenames are like "inputXX.txt"
    filename_base = os.path.basename(input_filepath)
    file_index = filename_base.replace("input", "").replace(".txt", "")

    output_filepath = f"output/output{file_index}.txt"
    error_filepath = f"output/output{file_index}_error.txt"

    try:
        # Read the entire content of the input file.
        with open(input_filepath, 'r') as f:
            input_content = f.read()

        # Redirect sys.stdin to read from the in-memory string.
        sys.stdin = io.StringIO(input_content)
        # Redirect sys.stdout to capture all print/write calls.
        sys.stdout = io.StringIO()

        # Execute the main solution logic. This will read from the redirected stdin
        # and write to the redirected stdout.
        execute_solution_code_block()

        # Get the captured output from the StringIO object.
        captured_output = sys.stdout.getvalue()

        # Write the captured output to the designated output file.
        with open(output_filepath, 'w') as f:
            f.write(captured_output)

    except Exception as e:
        # If any error occurs during processing of a file, catch it,
        # and write the error message to a dedicated error file.
        with open(error_filepath, 'w') as f:
            f.write(f"Error processing {input_filepath}:\n{str(e)}\n")
    finally:
        # Crucially, restore sys.stdin and sys.stdout to their original states
        # in a `finally` block to ensure this happens even if an error occurred.
        sys.stdin = original_stdin
        sys.stdout = original_stdout