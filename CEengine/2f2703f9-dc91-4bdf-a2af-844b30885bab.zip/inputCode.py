import random
import os
import math

# Constants from constraints
MAX_COORD_VAL = 10**9
MIN_COORD_VAL = -10**9
MAX_TARGET_VAL = 2 * 10**9
MIN_TARGET_VAL = -2 * 10**9
MAX_MATRIX_ELEMENTS_SUM = 100000

# Helper function to write a single test case to a file
def write_test_case(f, M, N, target, matrix):
    f.write(f"{M} {N} {target}\n")
    for row in matrix:
        f.write(" ".join(map(str, row)) + "\n")

# Helper function to create a matrix where flattened elements are already sorted
def create_globally_sorted_matrix(M, N):
    K = M * N
    mat = []
    current_val = 1
    for r in range(M):
        row = []
        for c in range(N):
            row.append(current_val)
            current_val += 1
        mat.append(row)
    target = 1 + K # Sum of smallest (1) and largest (K) elements
    return mat, target

# Helper function to create a matrix that targets median-of-three QuickSort
def create_median_killer_matrix(M, N):
    K = M * N
    candidate = list(range(K))
    temp_killer_flat = [0] * K

    # Construct the median-of-three killer sequence
    for i in range(K // 2):
        temp_killer_flat[2 * i] = candidate[i]
        temp_killer_flat[2 * i + 1] = candidate[K - 1 - i]
    if K % 2 == 1:
        temp_killer_flat[K - 1] = candidate[K // 2]
    
    # Ensure rows are sorted as per problem constraints
    mat = []
    for r in range(M):
        row_start_idx = r * N
        row_elements = sorted(temp_killer_flat[row_start_idx : row_start_idx + N])
        mat.append(row_elements)
    
    # Target is sum of first and last elements of the constructed flat array
    target = temp_killer_flat[0] + temp_killer_flat[K - 1]
    return mat, target

# Helper function to create matrices with no sum (for input07)
def create_no_sum_matrix(M, N, case_type):
    K = M * N
    mat = []
    
    if case_type == 0: # All elements positive and even, target odd
        target = 1
        for r in range(M):
            row = []
            for c in range(N):
                row.append((r * N + c) * 2 + 2) # Ensure all positive and even
            mat.append(row)
    elif case_type == 1: # All elements very large positive, target 0
        min_val_in_matrix = 10**9
        for r in range(M):
            row = []
            for c in range(N):
                val = min_val_in_matrix + (r * N + c)
                row.append(val)
            mat.append(row)
        target = 0
    elif case_type == 2: # All elements very large negative, target 0
        # Start from a value that will result in large negative numbers
        base_val = -10**9 - K 
        for r in range(M):
            row = []
            for c in range(N):
                val = base_val + (r * N + c) # Ensures sorted and negative
                row.append(val)
            mat.append(row)
        target = 0
    elif case_type == 3: # Elements positive, target too large
        max_val = -float('inf')
        second_max_val = -float('inf')
        for r in range(M):
            row = []
            for c in range(N):
                val = r * N + c + 1
                row.append(val)
                if val > max_val:
                    second_max_val = max_val
                    max_val = val
                elif val > second_max_val:
                    second_max_val = val
            mat.append(row)
        target = max_val + second_max_val + 10**9 # Guaranteed to be larger
    elif case_type == 4: # Elements negative, target too small
        min_val = float('inf')
        second_min_val = float('inf')
        for r in range(M):
            row = []
            for c in range(N):
                val = -(r * N + c + 1)
                row.append(val)
                if val < min_val:
                    second_min_val = min_val
                    min_val = val
                elif val < second_min_val:
                    second_min_val = val
            mat.append(row)
        target = min_val + second_min_val - 10**9 # Guaranteed to be smaller
    elif case_type == 5: # Elements are multiples of 100, target 150 (sparse)
        for r in range(M):
            row = []
            for c in range(N):
                row.append((r * N + c + 1) * 100)
            mat.append(row)
        target = 150
    else:
        raise ValueError(f"Unknown case_type: {case_type}")

    return mat, target

# Ensure the 'input' directory exists
os.makedirs("input", exist_ok=True)

# TYPE: sample
# TARGETS: N/A
# SUM_N: N/A (exact string copy)
def generate_input00():
    with open("input/input00.txt", "w") as f:
        f.write("""2
3 3 10
1 2 3
4 5 6
7 8 9
2 2 0
-5 -1
0 4
""")

# TYPE: generic
# TARGETS: Basic correctness for various typical inputs.
# SUM_N: 100000 (approximate sum over T=4 cases)
def generate_input01():
    T = 4
    with open("input/input01.txt", "w") as f:
        f.write(f"{T}\n")
        remaining_total_k = MAX_MATRIX_ELEMENTS_SUM 

        for t_idx in range(T):
            min_k_allowed = 1000 
            max_k_allowed = 50000 
            
            # Dynamically adjust min/max K for current case to stay within total_k_sum constraint
            current_min_k = max(min_k_allowed, remaining_total_k - (T - 1 - t_idx) * max_k_allowed)
            current_max_k = min(max_k_allowed, remaining_total_k - (T - 1 - t_idx) * min_k_allowed)
            
            if current_min_k > current_max_k: # Handle tight constraints
                k = current_min_k
            else:
                k = random.randint(current_min_k, current_max_k)
            
            remaining_total_k -= k

            # Generate M, N for this k, aiming for varied shapes
            M = random.randint(1, min(k, int(math.sqrt(k)) + 1 if k > 0 else 1)) # M up to sqrt(K)
            if M == 0: M = 1 # Ensure M >= 1
            N = k // M
            if N == 0: N = 1 # Ensure N >= 1
            
            actual_k = M * N # Use the actual K that results from M*N

            mat = []
            flat_elements_for_target = []
            
            for _ in range(M):
                row_elements = []
                for _ in range(N):
                    row_elements.append(random.randint(MIN_COORD_VAL, MAX_COORD_VAL))
                row_elements.sort() # Ensure row is sorted
                mat.append(row_elements)
                flat_elements_for_target.extend(row_elements)
            
            target = 0
            if actual_k >= 2 and random.random() < 0.7: # 70% chance for a YES case
                # Flattened elements are needed for target calculation across the whole matrix
                # Sort flat_elements_for_target to easily pick sums
                flat_elements_for_target.sort() 
                
                idx1 = random.randint(0, actual_k - 1)
                idx2 = random.randint(0, actual_k - 1)
                while idx1 == idx2 and actual_k > 1: # Ensure distinct elements or indices if values are same
                    idx2 = random.randint(0, actual_k - 1)
                
                target = flat_elements_for_target[idx1] + flat_elements_for_target[idx2]

            else: # 30% chance for a NO case
                if actual_k < 2: # Cannot form a pair
                    target = random.randint(MIN_TARGET_VAL, MAX_TARGET_VAL)
                    if actual_k == 1: # if K=1, target must be != 2*element
                        target = mat[0][0] * 2 + (1 if random.random() < 0.5 else -1)
                else:
                    flat_elements_for_target.sort()
                    min_sum = flat_elements_for_target[0] + flat_elements_for_target[1]
                    max_sum = flat_elements_for_target[actual_k-1] + flat_elements_for_target[actual_k-2]
                    
                    if random.random() < 0.5: # Target too small
                        target = random.randint(MIN_TARGET_VAL, min_sum - 1)
                    else: # Target too large
                        target = random.randint(max_sum + 1, MAX_TARGET_VAL)
            
            # Clamp target to constraints
            target = max(MIN_TARGET_VAL, min(MAX_TARGET_VAL, target))

            write_test_case(f, M, N, target, mat)

# TYPE: edge
# TARGETS: Loop bounds for two-pointer when K < 2; incorrect indexing/off-by-one; handling duplicates.
# SUM_N: 1+2+2+4 = 9
def generate_input02():
    with open("input/input02.txt", "w") as f:
        T = 4
        f.write(f"{T}\n")

        # Case 1: Single element matrix (no pair possible)
        M1, N1, target1 = 1, 1, 10
        mat1 = [[5]]
        write_test_case(f, M1, N1, target1, mat1)

        # Case 2: Two elements, sum exists
        M2, N2, target2 = 1, 2, 10
        mat2 = [[3, 7]]
        write_test_case(f, M2, N2, target2, mat2)

        # Case 3: Two elements, sum doesn't exist
        M3, N3, target3 = 2, 1, 5
        mat3 = [[1], [2]] # Flattened: [1, 2] -> max sum 1+2=3
        write_test_case(f, M3, N3, target3, mat3)

        # Case 4: All elements identical, sum exists
        M4, N4, target4 = 2, 2, 10
        mat4 = [[5, 5], [5, 5]] # Flattened: [5, 5, 5, 5] -> 5+5=10
        write_test_case(f, M4, N4, target4, mat4)

# TYPE: edge
# TARGETS: Integer overflow/underflow; issues with zero/mixed signs; target out of possible range.
# SUM_N: 4+6+4+4+4 = 22
def generate_input03():
    with open("input/input03.txt", "w") as f:
        T = 5
        f.write(f"{T}\n")

        # Case 1: All negative elements, negative target
        M1, N1, target1 = 2, 2, -7
        mat1 = [[-10, -5], [-2, -1]] # Flattened: [-10, -5, -2, -1]. Sum -5 + -2 = -7
        write_test_case(f, M1, N1, target1, mat1)

        # Case 2: Mixed signs, target zero
        M2, N2, target2 = 2, 3, 0
        mat2 = [[-5, -1, 0], [1, 2, 5]] # Flattened: [-5, -1, 0, 1, 2, 5]. Sum -5+5=0, -1+1=0
        write_test_case(f, M2, N2, target2, mat2)

        # Case 3: Target out of possible sum range (too large)
        M3, N3, target3 = 2, 2, 100
        mat3 = [[1, 2], [3, 4]] # Max sum: 3+4=7. Target 100.
        write_test_case(f, M3, N3, target3, mat3)

        # Case 4: Target out of possible sum range (too small)
        M4, N4, target4 = 2, 2, -5
        mat4 = [[1, 2], [3, 4]] # Min sum: 1+2=3. Target -5.
        write_test_case(f, M4, N4, target4, mat4)
        
        # Case 5: Target equals x+x (two distinct elements with same value)
        M5, N5, target5 = 2, 2, 10
        mat5 = [[5, 5], [10, 10]] # Flattened: [5, 5, 10, 10]. Sum 5+5=10.
        write_test_case(f, M5, N5, target5, mat5)

# TYPE: edge
# TARGETS: Inefficient iteration/search for very wide/tall matrices; incorrect scope assumptions (same/diff row).
# SUM_N: 1000+1000+9 = 2009
def generate_input04():
    with open("input/input04.txt", "w") as f:
        T = 3
        f.write(f"{T}\n")

        # Case 1: Very wide matrix (M=1), sum within row
        M1, N1 = 1, 1000
        mat1 = [list(range(1, N1 + 1))] # [1, 2, ..., 1000]
        target1 = 1001 # 1 + 1000
        write_test_case(f, M1, N1, target1, mat1)

        # Case 2: Very tall matrix (N=1), sum across rows
        M2, N2 = 1000, 1
        mat2 = [[i] for i in range(1, M2 + 1)] # [[1], [2], ..., [1000]]
        target2 = 1001 # 1 + 1000
        write_test_case(f, M2, N2, target2, mat2)

        # Case 3: Target requires elements from different rows
        M3, N3, target3 = 3, 3, 10
        mat3 = [[1,2,3],[4,5,6],[7,8,9]] # Flattened: [1,...,9]. 1+9=10 (mat[0][0]+mat[2][2])
        write_test_case(f, M3, N3, target3, mat3)

# TYPE: large
# TARGETS: O(K^2) sorting algorithms (e.g., naive QuickSort with fixed pivot) for already sorted arrays.
# SUM_N: 50000+30000+20000 = 100000
def generate_input05():
    with open("input/input05.txt", "w") as f:
        T = 3
        f.write(f"{T}\n")

        k_values = [50000, 30000, 20000]

        for i in range(T):
            k = k_values[i]
            M = 100 
            N = k // M # Ensure M*N == K

            mat, target = create_globally_sorted_matrix(M, N)
            write_test_case(f, M, N, target, mat)

# TYPE: large
# TARGETS: O(K^2) QuickSort with median-of-three pivot by carefully constructed input.
# SUM_N: 50000+30000+20000 = 100000
def generate_input06():
    with open("input/input06.txt", "w") as f:
        T = 3
        f.write(f"{T}\n")

        k_values = [50000, 30000, 20000]

        for i in range(T):
            k = k_values[i]
            M = 100 
            N = k // M # Ensure M*N == K

            mat, target = create_median_killer_matrix(M, N)
            write_test_case(f, M, N, target, mat)

# TYPE: large
# TARGETS: Maximize total `M*N` over all test cases; verify correctness for `NO` cases under load; stress-test extreme values.
# SUM_N: 10 * 10000 = 100000
def generate_input07():
    with open("input/input07.txt", "w") as f:
        T = 10
        f.write(f"{T}\n")

        k_per_case = 10000
        
        # Define M,N combinations for K=10000
        m_n_combinations = [
            (1, 10000),       # Very wide
            (10000, 1),       # Very tall
            (100, 100),       # Squarish
            (50, 200),        # Rectangular
            (200, 50),        # Rectangular (flipped)
            (10, 1000),       # Wider
            (1000, 10),       # Taller
            (1, 10000),       # Repeat wide
            (100, 100),       # Repeat squarish
            (50, 200)         # Repeat rectangular
        ]
        
        # Cycle through case types for variety in 'NO' conditions
        case_types = [0, 1, 2, 3, 4, 5, 0, 1, 2, 3] # Cycle through cases 0-5

        for i in range(T):
            M, N = m_n_combinations[i]
            case_type = case_types[i]
            
            mat, target = create_no_sum_matrix(M, N, case_type)
            write_test_case(f, M, N, target, mat)

if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()
    generate_input06()
    generate_input07()