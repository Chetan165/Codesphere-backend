import sys
import io
import os
import glob

def solve():
    s = sys.stdin.readline().strip()
    if not s:
        return
    n = len(s)
    ans = 0
    for k in range(n // 2, 0, -1):
        if s[:k] == s[n-k:]:
            ans = k
            break
    print(ans)

def run_solution():
    line = sys.stdin.readline()
    if line:
        t_str = line.strip()
        if t_str:
            try:
                T = int(t_str)
                for _ in range(T):
                    solve()
            except ValueError:
                pass

def main():
    os.makedirs("output", exist_ok=True)
    input_files = sorted(glob.glob("input/input*.txt"))
    for input_path in input_files:
        basename = os.path.basename(input_path)
        index = basename.replace("input", "").replace(".txt", "")
        output_path = os.path.join("output", f"output{index}.txt")
        error_path = os.path.join("output", f"output{index}_error.txt")
        try:
            with open(input_path, 'r') as f:
                file_content = f.read()
            sys.stdin = io.StringIO(file_content)
            sys.stdout = io.StringIO()
            run_solution()
            output = sys.stdout.getvalue()
            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__
            with open(output_path, 'w') as f:
                f.write(output)
        except Exception as e:
            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__
            with open(error_path, 'w') as f:
                f.write(str(e))

if __name__ == "__main__":
    main()