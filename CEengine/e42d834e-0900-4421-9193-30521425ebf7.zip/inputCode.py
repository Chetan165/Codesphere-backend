import random
import os
import string
import math


# TYPE: sample
# TARGETS: basic correctness
# SUM_N: 7+5+7+4 = 23
def generate_input00():
    os.makedirs("input", exist_ok=True)
    with open("input/input00.txt", "w") as f:
        f.write("""4
abcabc
aaaaa
abacaba
abcd
""")


# TYPE: edge
# TARGETS: k<=n/2 boundary, off-by-one errors, single char, exact half boundary
# SUM_N: 1+2+2+3+5+6+5+6 = 30
def generate_input01():
    os.makedirs("input", exist_ok=True)
    cases = []
    # single_char
    cases.append("a")
    # two_same_chars
    cases.append("aa")
    # two_diff_chars
    cases.append("ab")
    # three_same_chars
    cases.append("aaa")
    # odd_all_same
    cases.append("aaaaa")
    # even_all_same
    cases.append("aaaaaa")
    # no_border_at_all
    cases.append("abcde")
    # border_exactly_half
    cases.append("abcabc")

    with open("input/input01.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for c in cases:
            f.write(c + "\n")


def create_all_same_char_cases(n):
    """Create a string of all 'a' characters with length n.
    For such a string, KMP failure is n-1 but the answer is floor(n/2).
    The solver must follow the failure chain from n-1 down to floor(n/2)."""
    return 'a' * n


# TYPE: large
# TARGETS: Solutions returning raw KMP failure without enforcing k<=n/2; failure chain traversal on highly periodic strings
# SUM_N: 999+1000+997+998+996 = 4990
def generate_input02():
    os.makedirs("input", exist_ok=True)
    n_values = [999, 1000, 997, 998, 996]
    cases = []
    for n in n_values:
        cases.append(create_all_same_char_cases(n))

    with open("input/input02.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for c in cases:
            f.write(c + "\n")


# TYPE: edge
# TARGETS: Failure chain traversal, off-by-one on n/2 boundary, missing shorter valid borders
# SUM_N: 9+8+7+7+10+5 = 46
def generate_input03():
    os.makedirs("input", exist_ok=True)
    cases = []

    # failure_chain_multi_step: s = 'aabaabaab', n=9
    # KMP failure[8]=6 > 4, follow chain: failure[5]=3 <= 4. Answer is 3.
    cases.append("aabaabaab")

    # border_one_less_than_half: s = 'abcdabcd', n=8
    # Border 'abcd' has length 4, n/2=4, k<=4 satisfied. Answer is 4.
    cases.append("abcdabcd")

    # only_short_border_valid: s = 'abababa', n=7
    # KMP failure[6]=5 > 3. failure[4]=3 <= 3. Answer is 3.
    cases.append("abababa")

    # palindrome_like: s = 'abacaba', n=7
    # KMP failure[6]=1 <= 3. Answer is 1.
    cases.append("abacaba")

    # border_at_one: s = 'abcdefghia', n=10
    # Only border is 'a' of length 1. Answer is 1.
    cases.append("abcdefghia")

    # no_valid_border_after_chain: s = 'aabaa', n=5
    # KMP failure[4]=2, 2 <= 2. Answer is 2.
    cases.append("aabaa")

    with open("input/input03.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for c in cases:
            f.write(c + "\n")


# TYPE: generic
# TARGETS: General correctness on random strings of varying lengths and alphabets
# SUM_N: varies, approximately 50 * 50 = 2500 on average
def generate_input04():
    os.makedirs("input", exist_ok=True)
    random.seed(42)
    T = 50
    cases = []
    for _ in range(T):
        n = random.randint(1, 100)
        s = ''.join(random.choice(string.ascii_lowercase) for _ in range(n))
        cases.append(s)

    total_n = sum(len(c) for c in cases)
    with open("input/input04.txt", "w") as f:
        f.write(f"{T}\n")
        for c in cases:
            f.write(c + "\n")


def create_periodic_killer_cases():
    """Create Fibonacci-like periodic strings and near-periodic strings
    that create deep failure chains."""
    cases = []

    # Case 1: Fibonacci string fib(16), length 987
    fib = ['a', 'b']
    for i in range(2, 16):
        fib.append(fib[i-1] + fib[i-2])
    cases.append(fib[15])  # fib(16) in 0-indexed = fib[15], length should be fib(16)=987

    # Case 2: 'ab' repeated 499 times plus 'a' = length 999
    # Border: prefix 'a(ba)*' of length 499 matches suffix. Answer is 499.
    cases.append("ab" * 499 + "a")

    # Case 3: 'abc' repeated 333 times = length 999
    # Border 'abc'*111 = length 333 matches prefix and suffix with k=333 <= 999/2=499. Answer is 333.
    # Actually longest border for 'abc'*333 has failure = 666 (since (abc)^333 has period 3).
    # failure[998] = 996, follow chain down. Actually for perfect period p=3, n=999:
    # failure[998] = 996 > 499. Chain: 993 > 499, ..., 498 <= 499. Answer = 498.
    # Wait, let me reconsider. For 'abcabcabc...' of length 999 (333 repetitions of 'abc'):
    # The failure function at position 998 = 996. We need k <= 499.
    # Following chain: 996, 993, 990, ..., 498. 498 <= 499. Answer = 498.
    # Actually 498 = 166 * 3, so prefix[0:498] = 'abc' * 166 and suffix = s[501:999] = 'abc' * 166. Yes.
    cases.append("abc" * 333)

    # Case 4: 'a'*500 + 'b' + 'a'*499 = length 1000
    # The prefix 'a'*499 matches suffix 'a'*499. k=499, n/2=500. 499<=500. Answer is 499.
    cases.append("a" * 500 + "b" + "a" * 499)

    # Case 5: 'ab'*250 + 'cd' + 'ab'*249 = length 500+2+498 = 1000
    # The prefix must match suffix. 'ab'*249 has length 498. Check if prefix[0:498] == suffix[502:1000].
    # prefix[0:498] = 'ab'*249, suffix = s[502:1000] = 'ab'*249. Yes, k=498 <= 500. Answer is 498.
    cases.append("ab" * 250 + "cd" + "ab" * 249)

    return cases


# TYPE: large
# TARGETS: Deep failure chains on Fibonacci and periodic strings; exact n/2 boundary checks
# SUM_N: 987+999+999+1000+1000 = 4985
def generate_input05():
    os.makedirs("input", exist_ok=True)
    cases = create_periodic_killer_cases()

    with open("input/input05.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for c in cases:
            f.write(c + "\n")


if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()