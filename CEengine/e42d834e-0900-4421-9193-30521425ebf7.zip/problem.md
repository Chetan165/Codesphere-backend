
# Problem Statement
You are given a string s consisting of lowercase English letters. A 'border' of a string is a substring that is both a prefix and a suffix of the string. Your task is to find the length of the longest border that does not overlap with itself. Formally, find the maximum integer k such that s[0...k-1] == s[n-k...n-1] and k <= n/2, where n is the length of the string. If no such k > 0 exists, the answer is 0.

## Input Format
The first line of input contains an integer T (1 <= T <= 100), representing the number of test cases.
Each of the following T lines contains a single string s consisting of lowercase English letters.
 
## Output Format
For each test case, output a single integer representing the length of the longest non-overlapping border.

## Constraints
1 <= T <= 100
1 <= |s| <= 1000
The sum of |s| over all test cases does not exceed 5000.
s consists only of lowercase English letters.

## Sample Input
```
4
abcabc
aaaaa
abacaba
abcd
```

## Sample Output
```
3
2
3
0
```

## Solution
```python
import sys

def solve():
    """
    Solves a single test case to find the length of the longest border 
    that does not overlap with itself.
    """
    s = sys.stdin.readline().strip()
    if not s:
        return
    
    n = len(s)
    # A border of length k exists if s[0...k-1] == s[n-k...n-1].
    # For the border to be non-overlapping, its length k must satisfy k <= n/2.
    # We iterate from the maximum possible non-overlapping length downwards.
    ans = 0
    for k in range(n // 2, 0, -1):
        # Python slicing: s[:k] is s[0...k-1], s[n-k:] is s[n-k...n-1].
        if s[:k] == s[n-k:]:
            ans = k
            break
    print(ans)

if __name__ == "__main__":
    # Standard template for reading T test cases.
    line = sys.stdin.readline()
    if line:
        t_str = line.strip()
        if t_str:
            try:
                T = int(t_str)
                for _ in range(T):
                    solve()
            except ValueError:
                pass
```
