
# Problem Statement
You are given a sequence of integers and an integer `K`. Your task is to identify the `K` elements that possess the highest "activity score". The activity score for an element `X` is calculated as the sum of `(index + 1)` for all its occurrences within the sequence. For example, if element `A` appears at indices `i_1, i_2, ..., i_m`, its activity score would be `(i_1 + 1) + (i_2 + 1) + ... + (i_m + 1)`.

If multiple elements have the same activity score, they should be ranked based on their numerical value in ascending order (smaller value is preferred). If both activity score and numerical value are identical, they should be ranked based on their first appearance index in the sequence in ascending order (smaller index is preferred).

Return a list of the top `K` elements, ordered according to these ranking rules: highest activity score first, then smallest numerical value, then smallest first appearance index. If there are fewer than `K` unique elements in the sequence, return all unique elements ordered by these rules.

## Input Format
The first line contains an integer `T`, the number of testcases.
For each testcase:
- The first line contains two integers `N` and `K`, separated by a space, where `N` is the length of the sequence and `K` is the number of elements to retrieve.
- The second line contains `N` integers `A_1, A_2, ..., A_N`, separated by spaces, representing the sequence.

## Output Format
For each testcase, print `K` (or fewer, if there aren't `K` unique elements) integers representing the top elements, space-separated, on a single line.

## Constraints
1 <= T <= 100
1 <= N <= 10^5
1 <= K <= N
0 <= A_i <= 10^9
The sum of N over all testcases does not exceed 2 * 10^5.

## Sample Input
```
2
5 2
10 20 10 30 20
7 3
5 1 5 2 5 1 3
```

## Sample Output
```
20 10
5 1 3
```

## Solution
```python
import heapq
import sys

def solve():
    N, K = map(int, sys.stdin.readline().split())
    A = list(map(int, sys.stdin.readline().split()))

    # element_data: { value -> [activity_score, first_appearance_index] }
    element_data = {}

    # Step 1: Populate the hash map with activity scores and first appearance indices
    # O(N) time complexity
    for i in range(N):
        current_value = A[i]
        current_index_score = i + 1  # Score contribution for this occurrence

        if current_value not in element_data:
            # First occurrence: store initial score and index
            element_data[current_value] = [current_index_score, i]
        else:
            # Subsequent occurrence: update activity score
            element_data[current_value][0] += current_index_score
            # first_appearance_index remains unchanged for subsequent occurrences
    
    # top_k_heap: a min-heap to maintain the K highest priority elements.
    # Each element in the heap is a tuple: (score, -value, -first_idx).
    # This tuple structure defines the priority for the *heap* operation:
    # - We want to find the K elements with HIGHEST priority.
    # - A min-heap, when used for 'K largest' (highest priority), stores items such that its root (heap[0])
    #   is the *lowest priority* among the K items currently in the heap.
    # - To make 'larger' tuples (lexicographically) correspond to 'higher priority' elements
    #   (according to problem rules: score desc, value asc, first_idx asc), we construct the tuple as:
    #   1. score: Higher score means higher priority. Use score directly.
    #   2. value: Smaller value means higher priority. Use -value (negate).
    #   3. first_idx: Smaller first_idx means higher priority. Use -first_idx (negate).
    #   So, a tuple (s1, -v1, -i1) is 'larger' (lexicographically) than (s2, -v2, -i2) if it has higher priority.
    top_k_heap = []

    # Step 2: Iterate through unique elements and maintain the top K in the heap
    # O(U log K) where U is number of unique elements, U <= N
    for value, data in element_data.items():
        score, first_idx = data
        
        # Create the priority tuple for the heap
        priority_tuple_for_heap = (score, -value, -first_idx)

        if len(top_k_heap) < K:
            # If the heap is not yet full, simply push the element
            heapq.heappush(top_k_heap, priority_tuple_for_heap)
        else:
            # If the heap is full (contains K elements), compare the new element
            # with the lowest priority element currently in the heap (heap[0]).
            # If the new element has higher priority (i.e., is 'larger' in our tuple comparison)
            # than the current lowest priority element, replace it.
            if priority_tuple_for_heap > top_k_heap[0]:
                heapq.heapreplace(top_k_heap, priority_tuple_for_heap)

    # Step 3: Extract results and sort them for the final output format
    # O(K log K) for extracting and sorting
    
    # The heap now contains at most K elements with the highest priority, 
    # but they are not necessarily in the required output order.
    
    # Convert heap elements back to (score, value, first_idx) for correct sorting
    result_elements_for_sorting = []
    while top_k_heap:
        h_score, h_neg_value, h_neg_first_idx = heapq.heappop(top_k_heap)
        # Convert negated values back to original for sorting keys
        result_elements_for_sorting.append((h_score, -h_neg_value, -h_neg_first_idx))
    
    # Sort according to problem statement rules:
    # 1. Highest activity score first (descending: -x[0])
    # 2. Then smallest numerical value (ascending: x[1])
    # 3. Then smallest first appearance index (ascending: x[2])
    result_elements_for_sorting.sort(key=lambda x: (-x[0], x[1], x[2]))

    # Extract just the values for the final output
    final_output_values = [item[1] for item in result_elements_for_sorting]
    
    sys.stdout.write(" ".join(map(str, final_output_values)) + "\n")

# Read the number of testcases
T = int(sys.stdin.readline())
for _ in range(T):
    solve()

```
