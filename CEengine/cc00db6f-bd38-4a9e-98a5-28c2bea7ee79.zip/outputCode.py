import sys
import os
import io
import heapq

# The provided solution code as a multi-line string.
# This string will be executed directly to process input and produce output.
SOLUTION_CODE = """
import heapq
import sys

def solve():
    N, K = map(int, sys.stdin.readline().split())
    A = list(map(int, sys.stdin.readline().split()))

    # element_data: { value -> [activity_score, first_appearance_index] }
    element_data = {}

    # Step 1: Populate the hash map with activity scores and first appearance indices
    # O(N) time complexity
    for i in range(N):
        current_value = A[i]
        current_index_score = i + 1  # Score contribution for this occurrence

        if current_value not in element_data:
            # First occurrence: store initial score and index
            element_data[current_value] = [current_index_score, i]
        else:
            # Subsequent occurrence: update activity score
            element_data[current_value][0] += current_index_score
            # first_appearance_index remains unchanged for subsequent occurrences
    
    # top_k_heap: a min-heap to maintain the K highest priority elements.
    # Each element in the heap is a tuple: (score, -value, -first_idx).
    # This tuple structure defines the priority for the *heap* operation:
    # - We want to find the K elements with HIGHEST priority.
    # - A min-heap, when used for 'K largest' (highest priority), stores items such that its root (heap[0])
    #   is the *lowest priority* among the K items currently in the heap.
    # - To make 'larger' tuples (lexicographically) correspond to 'higher priority' elements
    #   (according to problem rules: score desc, value asc, first_idx asc), we construct the tuple as:
    #   1. score: Higher score means higher priority. Use score directly.
    #   2. value: Smaller value means higher priority. Use -value (negate).
    #   3. first_idx: Smaller first_idx means higher priority. Use -first_idx (negate).
    #   So, a tuple (s1, -v1, -i1) is 'larger' (lexicographically) than (s2, -v2, -i2) if it has higher priority.
    top_k_heap = []

    # Step 2: Iterate through unique elements and maintain the top K in the heap
    # O(U log K) where U is number of unique elements, U <= N
    for value, data in element_data.items():
        score, first_idx = data
        
        # Create the priority tuple for the heap
        priority_tuple_for_heap = (score, -value, -first_idx)

        if len(top_k_heap) < K:
            # If the heap is not yet full, simply push the element
            heapq.heappush(top_k_heap, priority_tuple_for_heap)
        else:
            # If the heap is full (contains K elements), compare the new element
            # with the lowest priority element currently in the heap (heap[0]).
            # If the new element has higher priority (i.e., is 'larger' in our tuple comparison)
            # than the current lowest priority element, replace it.
            if priority_tuple_for_heap > top_k_heap[0]:
                heapq.heapreplace(top_k_heap, priority_tuple_for_heap)

    # Step 3: Extract results and sort them for the final output format
    # O(K log K) for extracting and sorting
    
    # The heap now contains at most K elements with the highest priority, 
    # but they are not necessarily in the required output order.
    
    # Convert heap elements back to (score, value, first_idx) for correct sorting
    result_elements_for_sorting = []
    while top_k_heap:
        h_score, h_neg_value, h_neg_first_idx = heapq.heappop(top_k_heap)
        # Convert negated values back to original for sorting keys
        result_elements_for_sorting.append((h_score, -h_neg_value, -h_neg_first_idx))
    
    # Sort according to problem statement rules:
    # 1. Highest activity score first (descending: -x[0])
    # 2. Then smallest numerical value (ascending: x[1])
    # 3. Then smallest first appearance index (ascending: x[2])
    result_elements_for_sorting.sort(key=lambda x: (-x[0], x[1], x[2]))

    # Extract just the values for the final output
    final_output_values = [item[1] for item in result_elements_for_sorting]
    
    sys.stdout.write(" ".join(map(str, final_output_values)) + "\n")

# Read the number of testcases
T = int(sys.stdin.readline())
for _ in range(T):
    solve()
"""

def generate_outputs():
    # Create the 'output' directory if it doesn't exist
    os.makedirs("output", exist_ok=True)
    
    # Get a sorted list of all generated input files
    input_files = sorted([f for f in os.listdir("input") if f.startswith("input") and f.endswith(".txt")])
    
    for input_filename in input_files:
        input_filepath = os.path.join("input", input_filename)
        # Determine the corresponding output file path
        output_filepath = os.path.join("output", input_filename.replace("input", "output"))
        
        with open(input_filepath, "r") as infile:
            input_content = infile.read()
            
        # Redirect standard input and output to capture the solution's I/O
        original_stdin = sys.stdin
        original_stdout = sys.stdout
        
        sys.stdin = io.StringIO(input_content) # Provide the input content to stdin
        sys.stdout = io.StringIO()             # Capture stdout
        
        try:
            # Execute the provided solution code. The solution code includes
            # its own loop for 'T' testcases, so it's executed once per input file.
            # An empty dictionary `{}` is passed for globals to ensure the execution
            # runs in an isolated namespace, preventing unintended side effects across files.
            exec(SOLUTION_CODE, {})
            
        finally:
            # Restore original stdin and stdout regardless of execution outcome
            captured_output = sys.stdout.getvalue()
            sys.stdin = original_stdin
            sys.stdout = original_stdout
            
        # Write the captured output to the designated output file
        with open(output_filepath, "w") as outfile:
            outfile.write(captured_output)

# Call the function to generate all output files
generate_outputs()
