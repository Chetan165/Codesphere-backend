import os
import random

def generate_input00():
    # Sample test case: as provided in the problem description.
    with open("input/input00.txt", "w") as f:
        f.write("2\n") # Number of testcases (T)
        f.write("5 2\n") # N K for the first testcase
        f.write("10 20 10 30 20\n") # Sequence A for the first testcase
        f.write("7 3\n") # N K for the second testcase
        f.write("5 1 5 2 5 1 3\n") # Sequence A for the second testcase

def generate_input01():
    # Edge test cases targeting specific small N and K values, and tie-breaking.
    with open("input/input01.txt", "w") as f:
        f.write("4\n") # Total of 4 testcases in this file

        # Testcase 1: Minimum N and K. Single element sequence.
        # N=1, K=1. A=[0]. Expected output: 0.
        f.write("1 1\n")
        f.write("0\n")

        # Testcase 2: All unique elements, K=N. Sorted sequence.
        # N=5, K=5. A=[10, 20, 30, 40, 50]. Scores are 10(1), 20(2), 30(3), 40(4), 50(5).
        # Expected output: 50 40 30 20 10.
        f.write("5 5\n")
        f.write("10 20 30 40 50\n")

        # Testcase 3: All elements are identical, K=1. Only one unique element.
        # N=5, K=1. A=[7, 7, 7, 7, 7]. Activity score for 7 = (1+2+3+4+5) = 15.
        # Expected output: 7.
        f.write("5 1\n")
        f.write("7 7 7 7 7\n")

        # Testcase 4: Designed to rigorously test tie-breaking rules.
        # N=10, K=3. A=[10, 100, 20, 10, 30, 20, 40, 50, 60, 70]
        # Element | Occurrences (indices) | Activity Score | First Index
        # --------|-----------------------|----------------|------------
        # 10      | 0, 3                  | (0+1)+(3+1)=5  | 0
        # 100     | 1                     | (1+1)=2        | 1
        # 20      | 2, 5                  | (2+1)+(5+1)=9  | 2
        # 30      | 4                     | (4+1)=5        | 4
        # 40      | 6                     | (6+1)=7        | 6
        # 50      | 7                     | (7+1)=8        | 7
        # 60      | 8                     | (8+1)=9        | 8
        # 70      | 9                     | (9+1)=10       | 9
        # Sorted unique elements by (-score, value, first_idx):
        # (10, 70, 9)  -> Value 70
        # (9, 20, 2)   -> Value 20 (preferred over 60 due to smaller numerical value)
        # (9, 60, 8)   -> Value 60
        # (8, 50, 7)   -> Value 50
        # (7, 40, 6)   -> Value 40
        # (5, 10, 0)   -> Value 10 (preferred over 30 due to smaller numerical value)
        # (5, 30, 4)   -> Value 30
        # (2, 100, 1)  -> Value 100
        # For K=3, the top elements are 70, 20, 60.
        f.write("10 3\n")
        f.write("10 100 20 10 30 20 40 50 60 70\n")

def generate_input02():
    # Large test case: Maximizes N and uses K = N/2 to stress performance.
    # Elements are a mix of frequently repeating small numbers (to accumulate scores)
    # and less frequent large numbers (to test large values and potentially many unique elements).
    # The sum of N over all testcases is capped at 2 * 10^5. This testcase uses a large portion of it.
    with open("input/input02.txt", "w") as f:
        N = 10**5 # Maximum N for a single testcase
        K = N // 2 # A moderate K to challenge the heap size
        f.write("1\n") # Only one testcase in this large file
        f.write(f"{N} {K}\n")

        elements = []
        # Generate a portion of values from a small range to ensure many duplicates and high scores
        for _ in range(N // 5): # 20,000 elements from 0-100
            elements.append(random.randint(0, 100))
        # Generate the remaining values from a much wider range, increasing uniqueness
        for _ in range(N - (N // 5)): # 80,000 elements from 0 to 10^9
            elements.append(random.randint(0, 10**9))

        random.shuffle(elements) # Randomize positions to vary activity score sums and first appearance indices
        f.write(" ".join(map(str, elements)) + "\n")

def generate_input03():
    # Another set of edge test cases, focusing on maximum N with K=1, many duplicates, and specific value patterns.
    # Total sum N is controlled to be within limits.
    with open("input/input03.txt", "w") as f:
        f.write("3\n") # Total of 3 testcases in this file

        # Testcase 1: Large N (5*10^4), K=1. All unique elements, sorted. Tests simple max score scenario.
        # N=50,000, K=1. A=[0, 1, 2, ..., 49999].
        # Element 'i' appears at index 'i'. Its activity score is (i+1).
        # The element 49999 (at index 49999) will have the highest score (50000).
        # Expected output: 49999.
        f.write(f"{5 * 10**4} 1\n")
        elements = list(range(5 * 10**4))
        f.write(" ".join(map(str, elements)) + "\n")

        # Testcase 2: N=100, K=10. Ten unique elements (0-9), each appearing 10 times.
        # This test ensures correct score accumulation and handling of many highly active elements.
        f.write("100 10\n")
        elements = []
        for _ in range(10): # Each of 0-9 appears 10 times
            for i in range(10):
                elements.append(i)
        random.shuffle(elements) # Shuffle to make index sums varied and non-trivial
        f.write(" ".join(map(str, elements)) + "\n")

        # Testcase 3: N=20, K=5. Only two unique elements (0 and 1), each appearing 10 times.
        # Tests scenario where K is larger than the number of unique elements found.
        # A=[0,0,...,0 (10 times), 1,1,...,1 (10 times)].
        # Score for 0: (0+1)+(1+1)+...+(9+1) = sum(1 to 10) = 55. First index: 0.
        # Score for 1: (10+1)+(11+1)+...+(19+1) = sum(11 to 20) = 155. First index: 10.
        # For K=5, only 2 unique elements are found. Sorted: 1 (score 155), 0 (score 55).
        # Expected output: 1 0.
        f.write("20 5\n")
        elements = [0] * 10 + [1] * 10
        f.write(" ".join(map(str, elements)) + "\n")


# Create the 'input' directory if it doesn't exist
os.makedirs("input", exist_ok=True)

# Generate all specified input files by calling their respective functions
generate_input00()
generate_input01()
generate_input02()
generate_input03()
