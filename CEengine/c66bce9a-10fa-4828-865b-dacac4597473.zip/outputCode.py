import sys
import os
import io
import glob

# The provided solution code as a string, to be executed in a controlled environment.
SOLUTION_CODE = """
import sys

sys.setrecursionlimit(2 * 10**5) # Increase recursion limit for potentially deep DFS

def solve():
    R, C, K = map(int, sys.stdin.readline().split())
    grid = []
    for _ in range(R):
        grid.append(sys.stdin.readline().strip())
    
    start_r, start_c = map(int, sys.stdin.readline().split())
    target_r, target_c = map(int, sys.stdin.readline().split())

    memo = {}

    def dfs(r, c, k_remaining):
        # Base case: If target is reached
        if (r, c) == (target_r, target_c):
            return True
        
        # Check memoization table
        state = (r, c, k_remaining)
        if state in memo:
            return memo[state]

        # Explore neighbors (Up, Down, Left, Right)
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            
            # Check if neighbor is within grid bounds
            if 0 <= nr < R and 0 <= nc < C:
                if grid[nr][nc] == 'S':
                    # Move to a safe cell without consuming cleaning operations
                    if dfs(nr, nc, k_remaining):
                        memo[state] = True # Path found from this state
                        return True
                elif grid[nr][nc] == 'C':
                    # Move to a contaminated cell, consumes a cleaning operation
                    if k_remaining > 0: # Only if cleaning operations are available
                        if dfs(nr, nc, k_remaining - 1):
                            memo[state] = True # Path found from this state
                            return True
        
        # If no path was found from this state through any neighbor
        memo[state] = False
        return False

    # Start DFS from the initial position with the full cleaning budget K.
    # The starting cell is guaranteed to be 'S', so no cleaning cost is incurred to 'start' there.
    if dfs(start_r, start_c, K):
        sys.stdout.write("YES\n")
    else:
        sys.stdout.write("NO\n")

# Read the number of test cases
num_testcases = int(sys.stdin.readline())
for _ in range(num_testcases):
    solve()
"""

def generate_outputs():
    os.makedirs("output", exist_ok=True)
    
    # Store original stdin and stdout
    original_stdin = sys.stdin
    original_stdout = sys.stdout

    # Find all input files
    # Sorting ensures consistent order, e.g., input00.txt, input01.txt, etc.
    input_files = sorted(glob.glob("input/input*.txt"))

    for input_filepath in input_files:
        output_filename = os.path.basename(input_filepath).replace("input", "output")
        output_filepath = os.path.join("output", output_filename)

        # Read input data from the file
        with open(input_filepath, 'r') as infile:
            input_data = infile.read()

        # Redirect stdin to read from our input_data string
        sys.stdin = io.StringIO(input_data)
        # Redirect stdout to capture the solution's output
        sys.stdout = io.StringIO()

        try:
            # Execute the solution code. 'exec' is used here because the solution code
            # includes global setup (like recursion limit) and a main loop.
            # It will run as if it were the main script, reading from the redirected stdin
            # and writing to the redirected stdout.
            exec(SOLUTION_CODE, globals())
        except Exception as e:
            # If an error occurs during execution, print it to the console for debugging
            # and write an error message to the output file.
            sys.stdout.write(f"Error: {e}\n")
        finally:
            # Retrieve the captured output
            output_data = sys.stdout.getvalue()
            # Restore original stdin and stdout to avoid interfering with subsequent operations
            sys.stdin = original_stdin
            sys.stdout = original_stdout

            # Write the captured output to the designated output file
            with open(output_filepath, 'w') as outfile:
                outfile.write(output_data)

# This block ensures that when the outputGenCode script is executed,
# the generate_outputs function is called to perform the task.
if __name__ == '__main__':
    generate_outputs()
