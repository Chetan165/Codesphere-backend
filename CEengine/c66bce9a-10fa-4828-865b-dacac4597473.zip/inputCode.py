import os
import random

def _write_test_case(f, R, C, K, grid, start_r, start_c, target_r, target_c):
    f.write(f"{R} {C} {K}\n")
    for row in grid:
        f.write("".join(row) + "\n")
    f.write(f"{start_r} {start_c}\n")
    f.write(f"{target_r} {target_c}\n")

def generate_input00():
    # Sample test case, exactly as provided
    os.makedirs("input", exist_ok=True)
    with open("input/input00.txt", "w") as f:
        f.write("4\n")
        # Test Case 1
        f.write("3 3 0\n")
        f.write("SSS\n")
        f.write("SSS\n")
        f.write("SSS\n")
        f.write("0 0\n")
        f.write("2 2\n")
        # Test Case 2
        f.write("3 3 1\n")
        f.write("SCS\n")
        f.write("SCS\n")
        f.write("SSS\n")
        f.write("0 0\n")
        f.write("0 2\n")
        # Test Case 3
        f.write("3 3 0\n")
        f.write("SCS\n")
        f.write("SCS\n")
        f.write("SSS\n")
        f.write("0 0\n")
        f.write("0 2\n")
        # Test Case 4
        f.write("3 3 2\n")
        f.write("SCC\n")
        f.write("CSC\n")
        f.write("CCS\n")
        f.write("0 0\n")
        f.write("0 2\n")

def generate_input01():
    # Edge test cases
    os.makedirs("input", exist_ok=True)
    with open("input/input01.txt", "w") as f:
        f.write("5\n") # T test cases

        # Test 1: 1x1 grid, K=0. Start/Target (0,0). Always YES.
        _write_test_case(f, 1, 1, 0, [['S']], 0, 0, 0, 0)

        # Test 2: Max grid, all 'S', K=0. Start (0,0), Target (99,99). Path exists without cleans. YES.
        R, C, K = 100, 100, 0
        grid = [['S'] * C for _ in range(R)]
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)

        # Test 3: Small grid, path blocked by 'C's, K=0. NO.
        R, C, K = 3, 3, 0
        grid = [['S', 'C', 'S'], ['C', 'C', 'C'], ['S', 'C', 'S']]
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)
        
        # Test 4: Path requires exactly K cleans. R=5, C=5, K=2. Start(0,0), Target(0,4).
        # Grid: S C S C S
        #       C C C C C
        #       S S S S S
        #       C C C C C
        #       S S S S S
        # Path (0,0) -> (0,1)C (clean) -> (0,2)S -> (0,3)C (clean) -> (0,4)S. Requires 2 cleans. K=2. YES.
        R, C, K = 5, 5, 2
        grid = [['S' for _ in range(C)] for _ in range(R)]
        for r_idx in range(R):
            for c_idx in range(C):
                if r_idx % 2 == 1: # Odd rows are all C
                    grid[r_idx][c_idx] = 'C'
                elif c_idx % 2 == 1: # Even rows, odd columns are C
                    grid[r_idx][c_idx] = 'C'
        grid[0][0] = 'S' # Ensure start is S
        grid[0][4] = 'S' # Ensure target is S
        _write_test_case(f, R, C, K, grid, 0, 0, 0, 4)

        # Test 5: Max grid, checkerboard pattern, K insufficient for any path. NO.
        # Path from (0,0) to (99,99) in a checkerboard needs 99 cleans. K=50 is insufficient.
        R, C, K = 100, 100, 50
        grid = [['S' if (r_idx + c_idx) % 2 == 0 else 'C' for c_idx in range(C)] for r_idx in range(R)]
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)

def generate_input02():
    # Large test case: Max R, C, K. Tests performance.
    os.makedirs("input", exist_ok=True)
    with open("input/input02.txt", "w") as f:
        f.write("1\n") # T=1 for large test case

        # Max R=100, C=100, K=50.
        # Grid: Checkerboard pattern. Any path from (0,0) to (99,99) needs 99 cleans.
        # K=50 is insufficient. Expected: NO.
        R, C, K = 100, 100, 50
        grid = [['S' if (r_idx + c_idx) % 2 == 0 else 'C' for c_idx in range(C)] for r_idx in range(R)]
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)

def generate_input03():
    # Generic test cases
    os.makedirs("input", exist_ok=True)
    with open("input/input03.txt", "w") as f:
        f.write("3\n") # T=3 generic test cases

        # Test 1: R=10, C=10, K=2. Path requires 1 clean. YES.
        R, C, K = 10, 10, 2
        grid = [['S'] * C for _ in range(R)]
        # Wall of 'C's, 3 cells wide, forcing a detour or clean
        grid[3][4], grid[3][5], grid[3][6] = 'C', 'C', 'C'
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)

        # Test 2: Same grid as Test 1, but K=0. Path requires 1 clean. NO.
        R, C, K = 10, 10, 0
        grid = [['S'] * C for _ in range(R)]
        grid[3][4], grid[3][5], grid[3][6] = 'C', 'C', 'C'
        _write_test_case(f, R, C, K, grid, 0, 0, R-1, C-1)
        
        # Test 3: R=10, C=10, K=10. Random 50/50 S/C grid. Start (0,0), Target (5,5).
        # This will test typical performance with some C's and moderate K.
        R, C, K = 10, 10, 10
        grid = [[random.choice(['S', 'C']) for _ in range(C)] for _ in range(R)]
        grid[0][0] = 'S'
        grid[5][5] = 'S'
        _write_test_case(f, R, C, K, grid, 0, 0, 5, 5)

def generate_input04():
    # Generic (random) test cases
    os.makedirs("input", exist_ok=True)
    with open("input/input04.txt", "w") as f:
        num_test_cases = 5
        f.write(f"{num_test_cases}\n")

        for _ in range(num_test_cases):
            R = random.randint(1, 100)
            C = random.randint(1, 100)
            K = random.randint(0, 50)
            
            grid = [[random.choice(['S', 'C']) for _ in range(C)] for _ in range(R)]
            
            start_r = random.randint(0, R - 1)
            start_c = random.randint(0, C - 1)
            target_r = random.randint(0, R - 1)
            target_c = random.randint(0, C - 1)
            
            # Ensure start and target are 'S' as per problem guarantee
            grid[start_r][start_c] = 'S'
            grid[target_r][target_c] = 'S'
            
            _write_test_case(f, R, C, K, grid, start_r, start_c, target_r, target_c)


if __name__ == '__main__':
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
