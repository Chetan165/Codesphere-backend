
# Problem Statement
You are given a grid representing a map. Each cell in the grid can be either safe ('S') or contaminated ('C'). Your goal is to find a path from a specified starting safe cell to a specified target safe cell.

You can move from your current cell to any adjacent cell (up, down, left, right). If you attempt to move into a contaminated cell ('C'), you must perform a special cleaning operation. Each cleaning operation transforms that specific contaminated cell into a safe cell, allowing you to pass through it. You have a limited budget for these cleaning operations, at most `K` operations in total.

Determine if it's possible to reach the target cell from the start cell using at most `K` cleaning operations.

## Input Format
The first line contains an integer `T`, the number of test cases.

For each test case:
The first line contains three integers `R`, `C`, and `K`, representing the number of rows, columns, and the maximum number of cleaning operations allowed, respectively.
The next `R` lines each contain `C` characters, forming the grid. Each character is either 'S' (safe) or 'C' (contaminated).
The next line contains two integers `start_row` and `start_col`, indicating the 0-indexed row and column of the starting cell.
The last line contains two integers `target_row` and `target_col`, indicating the 0-indexed row and column of the target cell.

It is guaranteed that both the starting cell and the target cell are initially 'S'.

## Output Format
For each test case, output a single line: "YES" if a path exists from the start cell to the target cell using at most `K` cleaning operations, and "NO` otherwise.

## Constraints
1 <= T <= 10
1 <= R, C <= 100
0 <= K <= 50
0 <= start_row, target_row < R
0 <= start_col, target_col < C

## Sample Input
```
4
3 3 0
SSS
SSS
SSS
0 0
2 2
3 3 1
SCS
SCS
SSS
0 0
0 2
3 3 0
SCS
SCS
SSS
0 0
0 2
3 3 2
SCC
CSC
CCS
0 0
0 2
```

## Sample Output
```
YES
YES
NO
YES
```

## Solution
```python
import sys

sys.setrecursionlimit(2 * 10**5) # Increase recursion limit for potentially deep DFS

def solve():
    R, C, K = map(int, sys.stdin.readline().split())
    grid = []
    for _ in range(R):
        grid.append(sys.stdin.readline().strip())
    
    start_r, start_c = map(int, sys.stdin.readline().split())
    target_r, target_c = map(int, sys.stdin.readline().split())

    # memo stores (r, c, k_remaining) -> boolean result
    # This prevents redundant computations and cycles for the same state (cell and remaining cleans).
    memo = {}

    def dfs(r, c, k_remaining):
        # Base case: If target is reached
        if (r, c) == (target_r, target_c):
            return True
        
        # Check memoization table
        state = (r, c, k_remaining)
        if state in memo:
            return memo[state]

        # Explore neighbors (Up, Down, Left, Right)
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            
            # Check if neighbor is within grid bounds
            if 0 <= nr < R and 0 <= nc < C:
                if grid[nr][nc] == 'S':
                    # Move to a safe cell without consuming cleaning operations
                    if dfs(nr, nc, k_remaining):
                        memo[state] = True # Path found from this state
                        return True
                elif grid[nr][nc] == 'C':
                    # Move to a contaminated cell, consumes a cleaning operation
                    if k_remaining > 0: # Only if cleaning operations are available
                        if dfs(nr, nc, k_remaining - 1):
                            memo[state] = True # Path found from this state
                            return True
        
        # If no path was found from this state through any neighbor
        memo[state] = False
        return False

    # Start DFS from the initial position with the full cleaning budget K.
    # The starting cell is guaranteed to be 'S', so no cleaning cost is incurred to 'start' there.
    if dfs(start_r, start_c, K):
        sys.stdout.write("YES\n")
    else:
        sys.stdout.write("NO\n")

# Read the number of test cases
num_testcases = int(sys.stdin.readline())
for _ in range(num_testcases):
    solve()

```
