
# Problem Statement
Given two strings $s$ and $t$, your task is to find the number of ways to form $t$ as a subsequence of $s$ such that no two characters chosen from $s$ are adjacent. 

Formally, you need to find the number of sequences of indices $(i_1, i_2, \dots, i_m)$ where $m$ is the length of string $t$, such that:
1. $0 \le i_1 < i_2 < \dots < i_m < |s|$
2. $s[i_j] = t[j]$ for all $1 \le j \le m$
3. $i_{j+1} - i_j > 1$ for all $1 \le j < m$

Since the answer can be very large, return it modulo $10^9 + 7$.

## Input Format
The first line contains an integer $T$, the number of test cases.
Each test case consists of two lines:
- The first line contains the string $s$.
- The second line contains the string $t$.
 
## Output Format
For each test case, output a single integer representing the number of valid non-adjacent subsequences modulo $10^9 + 7$.

## Constraints
1 <= T <= 100
1 <= |s|, |t| <= 2000
The sum of |s| over all test cases does not exceed 5000.
The sum of |t| over all test cases does not exceed 5000.
s and t consist only of lowercase English letters.

## Sample Input
```
3
ababa
aa
banana
aa
aaaaa
aa
```

## Sample Output
```
3
3
6
```

## Solution
```python
import sys
import itertools

def get_tokens():
    for line in sys.stdin:
        for token in line.split():
            yield token

tokens = get_tokens()

def solve():
    try:
        s = next(tokens)
        t = next(tokens)
    except StopIteration:
        return

    n = len(s)
    m = len(t)
    MOD = 10**9 + 7
    
    # Pre-calculate positions of each character in string s
    # pos[c] stores all 1-based indices i where s[i-1] == character c
    pos = [[] for _ in range(26)]
    for i, char in enumerate(s):
        pos[ord(char) - 97].append(i + 1)
        
    # S_prev[i] will store the prefix sum of ways to form the prefix of t
    # considered so far, using characters from s[0...i-1].
    S_prev = [0] * (n + 1)
    
    for j in range(m):
        # dp_curr[i] will store the number of ways to form t[0...j] 
        # with the character t[j] mapped specifically to s[i-1].
        dp_curr = [0] * (n + 1)
        char_idx_list = pos[ord(t[j]) - 97]
        
        if j == 0:
            # Base case: first character of t
            for i in char_idx_list:
                dp_curr[i] = 1
        else:
            # General case: for each position i of t[j] in s, we find
            # how many ways to form t[0...j-1] using s up to index i-2.
            # This ensures the non-adjacency constraint: index_j - index_{j-1} > 1.
            for i in char_idx_list:
                if i >= 2:
                    dp_curr[i] = S_prev[i-2]
        
        # Compute prefix sums of dp_curr to fill S_prev for the next j iteration.
        # S_prev[k] = sum(dp_curr[0...k])
        # Using itertools.accumulate and list comprehension is faster in Python.
        raw_accumulate = itertools.accumulate(dp_curr)
        S_prev = [x % MOD for x in raw_accumulate]
        
    # The final answer is the number of ways to form the full string t
    # using any valid subsequence of s, which is the total sum of dp_curr.
    if m == 0:
        print(0)
    else:
        print(S_prev[n])

def main():
    try:
        T_str = next(tokens)
        T = int(T_str)
        for _ in range(T):
            solve()
    except (StopIteration, ValueError):
        pass

if __name__ == '__main__':
    main()
```
