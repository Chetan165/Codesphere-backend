import random
import os
import string

# TYPE: sample
# TARGETS: basic correctness check
# SUM_N: small sample
def generate_input00():
    os.makedirs("input", exist_ok=True)
    with open("input/input00.txt", "w") as f:
        f.write("""3
ababa
aa
banana
aa
aaaaa
aa
""")

# TYPE: edge
# TARGETS: Off-by-one in base case, uninitialized values, impossible cases, adjacency minimum length
# SUM_N: sum of |s| = 1+1+3+2 = 7, sum of |t| = 1+1+6+2 = 10
def generate_input01():
    os.makedirs("input", exist_ok=True)
    cases = []
    # single_char_match
    cases.append(("a", "a"))
    # single_char_no_match
    cases.append(("a", "b"))
    # t_longer_than_s
    cases.append(("abc", "abcabc"))
    # s_too_short_for_nonadj
    cases.append(("ab", "ab"))
    with open("input/input01.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

# TYPE: edge
# TARGETS: Incorrect transition when all characters match, combinatorial counting errors, adjacency constraint with patterns
# SUM_N: sum of |s| = 5+7+5+8 = 25, sum of |t| = 2+3+3+2 = 10
def generate_input02():
    os.makedirs("input", exist_ok=True)
    cases = []
    # all_a_small: s='aaaaa', t='aa', answer=6
    cases.append(("aaaaa", "aa"))
    # all_a_three: s='aaaaaaa', t='aaa', answer=10
    cases.append(("aaaaaaa", "aaa"))
    # all_a_impossible: s='aaaaa', t='aaa', answer=1
    cases.append(("aaaaa", "aaa"))
    # repeated_pattern: s='abababab', t='ab', answer=6
    cases.append(("abababab", "ab"))
    with open("input/input02.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

# TYPE: edge
# TARGETS: dp[i-2] boundary access when i<2, adjacency not enforced, single-char t counting
# SUM_N: sum of |s| = 5+5+6+15 = 31, sum of |t| = 1+1+2+1 = 5
def generate_input03():
    os.makedirs("input", exist_ok=True)
    cases = []
    # match_at_index_0_only
    cases.append(("abbbb", "a"))
    # match_at_index_1_only
    cases.append(("babbb", "a"))
    # adjacent_only_matches
    cases.append(("ccabcc", "ab"))
    # large_answer_small_input
    cases.append(("a" * 15, "a"))
    with open("input/input03.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

# TYPE: generic
# TARGETS: General correctness validation with medium-sized random inputs
# SUM_N: sum of |s| ~ 10 * ~110 = ~1100, sum of |t| ~ similar
def generate_input04():
    os.makedirs("input", exist_ok=True)
    random.seed(42)
    T = 10
    cases = []
    for _ in range(T):
        n_s = random.randint(20, 200)
        n_t = random.randint(1, max(1, n_s // 2))
        alphabet_size = random.randint(1, 26)
        chars = string.ascii_lowercase[:alphabet_size]
        s = ''.join(random.choice(chars) for _ in range(n_s))
        t = ''.join(random.choice(chars) for _ in range(n_t))
        cases.append((s, t))
    with open("input/input04.txt", "w") as f:
        f.write(f"{T}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

def create_all_same_killer(n):
    """Creates test cases with all-same characters. n is used to index predefined cases."""
    # Predefined cases:
    # n=2000: s='a'*2000, t='a'*1000
    # n=1999: s='a'*1999, t='a'*500
    # n=1001: s='a'*1001, t='a'*501
    configs = {
        2000: (2000, 1000),
        1999: (1999, 500),
        1001: (1001, 501),
    }
    s_len, t_len = configs[n]
    s = 'a' * s_len
    t = 'a' * t_len
    return s, t

# TYPE: large
# TARGETS: Naive recursion without memoization (exponential); stresses modular arithmetic with maximum overlapping subproblems
# SUM_N: sum of |s| = 2000+1999+1001 = 5000, sum of |t| = 1000+500+501 = 2001
def generate_input05():
    os.makedirs("input", exist_ok=True)
    n_values = [2000, 1999, 1001]
    T = 3
    cases = []
    for n in n_values:
        s, t = create_all_same_killer(n)
        cases.append((s, t))
    with open("input/input05.txt", "w") as f:
        f.write(f"{T}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

def create_alternating_killer(n):
    """Creates alternating pattern test cases. n is the length of s."""
    # Predefined cases:
    # n=2000: s='ab'*1000, t='ab'*400
    # n=1500 (first): s='ab'*750, t='ba'*600
    # n=1500 (second): s='ab'*750, t='ab'*500
    configs = {
        (2000, 0): ('ab' * 1000, 'ab' * 400),
        (1500, 1): ('ab' * 750, 'ba' * 600),
        (1500, 2): ('ab' * 750, 'ab' * 500),
    }
    return configs.get(n)

# TYPE: large
# TARGETS: Adjacency constraint enforcement across many transitions; O(N^3) solutions TLE
# SUM_N: sum of |s| = 2000+1500+1500 = 5000, sum of |t| = 800+1200+1000 = 3000
def generate_input06():
    os.makedirs("input", exist_ok=True)
    T = 3
    cases = []
    # Case 1: s='ab'*1000 (len 2000), t='ab'*400 (len 800)
    cases.append(('ab' * 1000, 'ab' * 400))
    # Case 2: s='ab'*750 (len 1500), t='ba'*600 (len 1200)
    cases.append(('ab' * 750, 'ba' * 600))
    # Case 3: s='ab'*750 (len 1500), t='ab'*500 (len 1000)
    cases.append(('ab' * 750, 'ab' * 500))
    with open("input/input06.txt", "w") as f:
        f.write(f"{T}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

def create_mixed_killer(n):
    """Not used as primary source; mixed cases are constructed inline."""
    pass

# TYPE: large
# TARGETS: Mix of easy-adjacency and hard-adjacency scenarios; cumulative effect stresses O(N^3) and unmemoized recursion
# SUM_N: sum of |s| = 4600, sum of |t| ~ 2300
def generate_input07():
    os.makedirs("input", exist_ok=True)
    random.seed(12345)
    s_lengths = [100, 150, 200, 250, 300, 350, 400, 180, 220, 280,
                 160, 340, 120, 260, 190, 310, 170, 230, 140, 210]
    T = 20
    cases = []
    for idx, s_len in enumerate(s_lengths):
        t_len = s_len // 2
        if idx % 2 == 0:
            # Even-indexed: single char repeated
            s = 'a' * s_len
            t = 'a' * t_len
        else:
            # Odd-indexed: random with only 'a','b'
            s = ''.join(random.choice('ab') for _ in range(s_len))
            # t is a random string of 'a','b' of length t_len
            t = ''.join(random.choice('ab') for _ in range(t_len))
        cases.append((s, t))
    with open("input/input07.txt", "w") as f:
        f.write(f"{T}\n")
        for s, t in cases:
            f.write(f"{s}\n{t}\n")

if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()
    generate_input06()
    generate_input07()