import sys
import os
import io
import glob
import itertools


def run_solution(file_content):
    def get_tokens():
        for line in file_content.splitlines():
            for token in line.split():
                yield token

    tokens = get_tokens()

    def solve():
        try:
            s = next(tokens)
            t = next(tokens)
        except StopIteration:
            return

        n = len(s)
        m = len(t)
        MOD = 10**9 + 7

        pos = [[] for _ in range(26)]
        for i, char in enumerate(s):
            pos[ord(char) - 97].append(i + 1)

        S_prev = [0] * (n + 1)

        for j in range(m):
            dp_curr = [0] * (n + 1)
            char_idx_list = pos[ord(t[j]) - 97]

            if j == 0:
                for i in char_idx_list:
                    dp_curr[i] = 1
            else:
                for i in char_idx_list:
                    if i >= 2:
                        dp_curr[i] = S_prev[i - 2]

            raw_accumulate = itertools.accumulate(dp_curr)
            S_prev = [x % MOD for x in raw_accumulate]

        if m == 0:
            return 0
        else:
            return S_prev[n]

    results = []
    try:
        T_str = next(tokens)
        T = int(T_str)
        for _ in range(T):
            result = solve()
            if result is not None:
                results.append(str(result))
    except (StopIteration, ValueError):
        pass

    return "\n".join(results)


def main():
    os.makedirs("output", exist_ok=True)

    input_files = sorted(glob.glob("input/input*.txt"))

    for input_filepath in input_files:
        basename = os.path.basename(input_filepath)
        index = basename.replace("input", "").replace(".txt", "")
        output_filepath = os.path.join("output", f"output{index}.txt")
        error_filepath = os.path.join("output", f"output{index}_error.txt")

        try:
            with open(input_filepath, "r") as f:
                file_content = f.read()

            output = run_solution(file_content)

            with open(output_filepath, "w") as f:
                f.write(output + "\n")

        except Exception as e:
            with open(error_filepath, "w") as f:
                f.write(str(e) + "\n")


if __name__ == "__main__":
    main()