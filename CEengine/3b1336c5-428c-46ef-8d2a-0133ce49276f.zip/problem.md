
# Problem Statement
You are given an array of integers `nums` and two integers `k` and `m`. Find the number of subarrays of length exactly `k` that contain at most `m` distinct elements.

A subarray is a contiguous non-empty sequence of elements within the array.

For each test case, output a single integer — the count of such subarrays.

## Input Format
The first line contains a single integer T — the number of test cases.

For each test case:
- The first line contains three integers n, k, and m (1 ≤ k ≤ n) — the length of the array, the required subarray length, and the maximum number of distinct elements allowed.
- The second line contains n integers nums[1], nums[2], ..., nums[n] — the elements of the array.
 
## Output Format
For each test case, print a single integer — the number of subarrays of length exactly k that contain at most m distinct elements.

## Constraints
1 ≤ T ≤ 10
1 ≤ n ≤ 200000
1 ≤ k ≤ n
1 ≤ m ≤ n
1 ≤ nums[i] ≤ 1000000
The sum of n across all test cases does not exceed 1000000.

## Sample Input
```
3
7 3 2
1 2 1 3 2 3 1
5 2 1
1 1 2 2 1
6 4 3
1 2 3 4 5 6
```

## Sample Output
```
4
3
3
```

## Solution
```python
import sys
from collections import defaultdict

input = sys.stdin.readline

def solve():
    n, k, m = map(int, input().split())
    nums = list(map(int, input().split()))
    
    freq = defaultdict(int)
    distinct = 0
    count = 0
    
    for i in range(n):
        # Add right element to window
        freq[nums[i]] += 1
        if freq[nums[i]] == 1:
            distinct += 1
        
        # Remove element that falls out of window
        if i >= k:
            left = nums[i - k]
            freq[left] -= 1
            if freq[left] == 0:
                distinct -= 1
        
        # Window is exactly size k
        if i >= k - 1:
            if distinct <= m:
                count += 1
    
    print(count)

T = int(input())
for _ in range(T):
    solve()
```
