import random
import os

# TYPE: sample
# TARGETS: basic correctness verification
# SUM_N: 18
def generate_input00():
    os.makedirs("input", exist_ok=True)
    with open("input/input00.txt", "w") as f:
        f.write("""3
7 3 2
1 2 1 3 2 3 1
5 2 1
1 1 2 2 1
6 4 3
1 2 3 4 5 6
""")

# TYPE: generic
# TARGETS: general logic bugs in frequency map maintenance and distinct counting
# SUM_N: ~7600 (varies with random)
def generate_input01():
    os.makedirs("input", exist_ok=True)
    T = 3
    cases = []
    for _ in range(T):
        n = random.randint(100, 5000)
        k = random.randint(1, n)
        m = random.randint(1, n)
        nums = [random.randint(1, 50) for _ in range(n)]
        cases.append((n, k, m, nums))
    with open("input/input01.txt", "w") as f:
        f.write(f"{T}\n")
        for n, k, m, nums in cases:
            f.write(f"{n} {k} {m}\n")
            f.write(" ".join(map(str, nums)) + "\n")

# TYPE: edge
# TARGETS: Off-by-one when n=k=1, failure with single window, no qualifying subarrays
# SUM_N: 11
def generate_input02():
    os.makedirs("input", exist_ok=True)
    with open("input/input02.txt", "w") as f:
        f.write("3\n")
        # single_element: n=1, k=1, m=1
        f.write("1 1 1\n")
        f.write("42\n")
        # k_equals_n: n=5, k=5, m=3
        f.write("5 5 3\n")
        f.write("1 2 1 2 1\n")
        # m=1 with all distinct: no window of size 3 has ≤1 distinct
        f.write("5 3 1\n")
        f.write("1 2 3 4 5\n")

# TYPE: edge
# TARGETS: trivial distinct count scenarios - all identical, k=1, m larger than n
# SUM_N: 23
def generate_input03():
    os.makedirs("input", exist_ok=True)
    with open("input/input03.txt", "w") as f:
        f.write("3\n")
        # all_identical_large_k: n=10, k=5, m=1
        f.write("10 5 1\n")
        f.write("7 7 7 7 7 7 7 7 7 7\n")
        # k_equals_1: n=8, k=1, m=1
        f.write("8 1 1\n")
        f.write("3 1 4 1 5 9 2 6\n")
        # m_larger_than_n: n=5, k=3, m=10
        f.write("5 3 10\n")
        f.write("1 2 3 4 5\n")

# TYPE: edge
# TARGETS: Off-by-one in <= vs < comparison, boundary distinct counts, frequency drop to zero
# SUM_N: 32
def generate_input04():
    os.makedirs("input", exist_ok=True)
    with open("input/input04.txt", "w") as f:
        f.write("3\n")
        # alternating_boundary_accept: n=10, k=4, m=2
        f.write("10 4 2\n")
        f.write("1 2 1 2 1 2 1 2 1 2\n")
        # alternating_boundary_reject: n=10, k=4, m=1
        f.write("10 4 1\n")
        f.write("1 2 1 2 1 2 1 2 1 2\n")
        # mixed_accept_reject: n=12, k=3, m=2
        f.write("12 3 2\n")
        f.write("1 1 1 2 3 4 1 1 2 2 2 2\n")

def create_cyclic_boundary_sequence(n):
    """Create cyclic pattern with 51 distinct values."""
    return [(i % 51) + 1 for i in range(n)]

# TYPE: large
# TARGETS: O(n*k) recompute approach with large k and cyclic patterns at distinct-count boundary
# SUM_N: 399997
def generate_input05():
    os.makedirs("input", exist_ok=True)
    with open("input/input05.txt", "w") as f:
        f.write("2\n")
        # TC1: n=200000, k=100000, m=50 -> all windows have 51 distinct > 50, answer=0
        n1 = 200000
        k1 = 100000
        m1 = 50
        nums1 = create_cyclic_boundary_sequence(n1)
        f.write(f"{n1} {k1} {m1}\n")
        f.write(" ".join(map(str, nums1)) + "\n")
        # TC2: n=199997, k=100000, m=51 -> all windows have 51 distinct <= 51, answer=99998
        n2 = 199997
        k2 = 100000
        m2 = 51
        nums2 = create_cyclic_boundary_sequence(n2)
        f.write(f"{n2} {k2} {m2}\n")
        f.write(" ".join(map(str, nums2)) + "\n")

def create_all_distinct_full_window(n):
    """Create array with all distinct elements: [1, 2, ..., n]."""
    return list(range(1, n + 1))

# TYPE: large
# TARGETS: O(n*k)=O(n^2) with k=n single window of maximum size stressing hash map size
# SUM_N: 399999
def generate_input06():
    os.makedirs("input", exist_ok=True)
    with open("input/input06.txt", "w") as f:
        f.write("2\n")
        # TC1: n=200000, k=200000, m=200000 -> 1 window, 200000 distinct <= 200000, answer=1
        n1 = 200000
        nums1 = create_all_distinct_full_window(n1)
        f.write(f"{n1} {n1} {n1}\n")
        f.write(" ".join(map(str, nums1)) + "\n")
        # TC2: n=199999, k=199999, m=199998 -> 1 window, 199999 distinct > 199998, answer=0
        n2 = 199999
        nums2 = create_all_distinct_full_window(n2)
        f.write(f"{n2} {n2} {n2 - 1}\n")
        f.write(" ".join(map(str, nums2)) + "\n")

def create_mixed_stress_cases():
    """Create 5 mixed stress test cases."""
    cases = []
    # TC1: all identical, n=200000, k=100000, m=1
    n1 = 200000
    cases.append((n1, 100000, 1, [999999] * n1))
    # TC2: alternating 2 values, n=200000, k=66667, m=1
    n2 = 200000
    nums2 = [(i % 2) + 1 for i in range(n2)]
    cases.append((n2, 66667, 1, nums2))
    # TC3: 501 distinct cycling, n=200000, k=100000, m=500
    n3 = 200000
    nums3 = [(i % 501) + 1 for i in range(n3)]
    cases.append((n3, 100000, 500, nums3))
    # TC4: 1000 values cycling, n=199993, k=3, m=2
    n4 = 199993
    nums4 = [(i % 1000) + 1 for i in range(n4)]
    cases.append((n4, 3, 2, nums4))
    # TC5: 100000 values cycling, n=199807, k=99904, m=50000
    n5 = 199807
    nums5 = [(i % 100000) + 1 for i in range(n5)]
    cases.append((n5, 99904, 50000, nums5))
    return cases

# TYPE: large
# TARGETS: O(n*k) across multiple large test cases with various patterns; total ~10^6
# SUM_N: 999800
def generate_input07():
    os.makedirs("input", exist_ok=True)
    cases = create_mixed_stress_cases()
    with open("input/input07.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for n, k, m, nums in cases:
            f.write(f"{n} {k} {m}\n")
            f.write(" ".join(map(str, nums)) + "\n")

if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()
    generate_input06()
    generate_input07()