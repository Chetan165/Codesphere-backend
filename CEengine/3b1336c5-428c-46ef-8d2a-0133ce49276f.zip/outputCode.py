import sys
import io
import os
import glob
from collections import defaultdict

def solve():
    n, k, m = map(int, input().split())
    nums = list(map(int, input().split()))
    
    freq = defaultdict(int)
    distinct = 0
    count = 0
    
    for i in range(n):
        freq[nums[i]] += 1
        if freq[nums[i]] == 1:
            distinct += 1
        
        if i >= k:
            left = nums[i - k]
            freq[left] -= 1
            if freq[left] == 0:
                distinct -= 1
        
        if i >= k - 1:
            if distinct <= m:
                count += 1
    
    print(count)

def run_on_file(input_path):
    with open(input_path, 'r') as f:
        file_content = f.read()
    
    sys.stdin = io.StringIO(file_content)
    sys.stdout = io.StringIO()
    
    try:
        input_func = sys.stdin.readline
        original_input = __builtins__.__dict__.get('input', None) if hasattr(__builtins__, '__dict__') else None
        
        # Override input to use sys.stdin.readline
        import builtins
        builtins.input = sys.stdin.readline
        
        T = int(sys.stdin.readline())
        for _ in range(T):
            solve()
        
        output = sys.stdout.getvalue()
    finally:
        sys.stdin = sys.__stdin__
        sys.stdout = sys.__stdout__
        import builtins
        builtins.input = original_input if original_input else sys.__stdin__.readline
    
    return output

def main():
    os.makedirs("output", exist_ok=True)
    
    input_files = sorted(glob.glob("input/input*.txt"))
    
    for input_path in input_files:
        basename = os.path.basename(input_path)
        # Extract index from filename like input00.txt or input_00.txt
        index = basename.replace("input", "").replace(".txt", "")
        output_path = os.path.join("output", f"output{index}.txt")
        error_path = os.path.join("output", f"output{index}_error.txt")
        
        try:
            output = run_on_file(input_path)
            with open(output_path, 'w') as f:
                f.write(output)
            print(f"Processed {input_path} -> {output_path}")
        except Exception as e:
            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__
            with open(error_path, 'w') as f:
                f.write(str(e))
            print(f"Error processing {input_path}: {e}")

if __name__ == "__main__":
    main()