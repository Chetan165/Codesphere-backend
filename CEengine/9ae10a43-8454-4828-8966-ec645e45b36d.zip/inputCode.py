import random
import os

# TYPE: sample
# TARGETS: basic logic
# SUM_N: 8
def generate_input00():
    os.makedirs("input", exist_ok=True)
    sample_input = """2
5 1 5
10 2 3 4 7
3 0 5
10 2 3
"""
    with open("input/input00.txt", "w") as f:
        f.write(sample_input.strip() + "\n")

# TYPE: edge
# TARGETS: fails when K is zero; assumes at least one drink; fails when budget is zero; result exceeds N when K > N.
# SUM_N: 13
def generate_input01():
    os.makedirs("input", exist_ok=True)
    cases = [
        {"n": 5, "k": 0, "d": 10, "tasks": [2, 3, 4, 5, 6]},
        {"n": 5, "k": 2, "d": 0, "tasks": [10, 20, 30, 40, 50]},
        {"n": 3, "k": 5, "d": 1, "tasks": [10, 10, 10]}
    ]
    with open("input/input01.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for case in cases:
            f.write(f"{case['n']} {case['k']} {case['d']}\n")
            f.write(" ".join(map(str, case['tasks'])) + "\n")

# TYPE: edge
# TARGETS: single task budget exceed; sorting tie-breaking; integer overflow on large single values.
# SUM_N: 13
def generate_input02():
    os.makedirs("input", exist_ok=True)
    cases = [
        {"n": 1, "k": 0, "d": 5, "tasks": [10]},
        {"n": 10, "k": 3, "d": 20, "tasks": [10]*10},
        {"n": 2, "k": 0, "d": 1000000000, "tasks": [1000000000, 1000000000]}
    ]
    with open("input/input02.txt", "w") as f:
        f.write(f"{len(cases)}\n")
        for case in cases:
            f.write(f"{case['n']} {case['k']} {case['d']}\n")
            f.write(" ".join(map(str, case['tasks'])) + "\n")

def generate_large_overflow(n):
    # Set all tasks[i] = 10^9. Set D = 10^9. Set K = 50000.
    tasks = [10**9] * n
    k = 50000
    d = 10**9
    return n, k, d, tasks

# TYPE: large
# TARGETS: O(N^2) algorithms; 32-bit integer overflow in sums.
# SUM_N: 199999
def generate_input03():
    os.makedirs("input", exist_ok=True)
    t = 2
    n_values = [100000, 99999]
    with open("input/input03.txt", "w") as f:
        f.write(f"{t}\n")
        for n in n_values:
            n_val, k_val, d_val, tasks = generate_large_overflow(n)
            f.write(f"{n_val} {k_val} {d_val}\n")
            f.write(" ".join(map(str, tasks)) + "\n")

def generate_budget_limited(n):
    # Set K=100. First 50000 tasks are 1, and the rest are 10^9. Set D=25000.
    k = 100
    d = 25000
    tasks = [1] * 50000
    if n > 50000:
        tasks += [10**9] * (n - 50000)
    else:
        # If n is smaller than 50k, adjust to fit n
        tasks = [1] * n
    return n, k, d, tasks

# TYPE: large
# TARGETS: O(N^2) search; incorrect greedy task selection.
# SUM_N: 180000
def generate_input04():
    os.makedirs("input", exist_ok=True)
    t = 2
    n_values = [100000, 80000]
    with open("input/input04.txt", "w") as f:
        f.write(f"{t}\n")
        for n in n_values:
            n_val, k_val, d_val, tasks = generate_budget_limited(n)
            f.write(f"{n_val} {k_val} {d_val}\n")
            f.write(" ".join(map(str, tasks)) + "\n")

def generate_n_limited(n):
    # Set K=10000. Set all task times to 1. Set D=10^9.
    k = 10000
    tasks = [1] * n
    d = 10**9
    return n, k, d, tasks

# TYPE: large
# TARGETS: Failing to cap the result at N when budget is excessive.
# SUM_N: 155000
def generate_input05():
    os.makedirs("input", exist_ok=True)
    t = 10
    n_values = [20000, 19000, 18000, 17000, 16000, 15000, 14000, 13000, 12000, 11000]
    with open("input/input05.txt", "w") as f:
        f.write(f"{t}\n")
        for n in n_values:
            n_val, k_val, d_val, tasks = generate_n_limited(n)
            f.write(f"{n_val} {k_val} {d_val}\n")
            f.write(" ".join(map(str, tasks)) + "\n")

if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()