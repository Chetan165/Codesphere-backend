
# Problem Statement
You are given N tasks, where each task i requires tasks[i] amount of time to complete. You have a total time budget of D units. Additionally, you are given K energy drinks. Using one energy drink allows you to complete any single task instantly (0 time). Each task can be completed at most once. Your goal is to find the maximum number of tasks you can complete given your time budget and the number of energy drinks available.

## Input Format
The first line of input contains an integer T, the number of test cases. Each test case consists of two lines:
1. Three space-separated integers N, K, and D, representing the number of tasks, the number of energy drinks, and the total time budget respectively.
2. N space-separated integers representing the time required for each task.
 
## Output Format
For each test case, output a single integer representing the maximum number of tasks that can be completed.

## Constraints
1 <= T <= 100
1 <= N <= 10^5
0 <= K <= N
1 <= D <= 10^9
1 <= tasks[i] <= 10^9
The sum of N over all test cases does not exceed 2 * 10^5.

## Sample Input
```
2
5 1 5
10 2 3 4 7
3 0 5
10 2 3
```

## Sample Output
```
3
2
```

## Solution
```python
import sys

# Global input iterator to be used by solve() for efficient input consumption
input_iter = iter([])

def solve():
    """
    Solves a single test case of the tasks and energy drinks problem.
    The logic follows a greedy approach:
    
    GREEDY PROOF:
    To maximize the total number of tasks completed (m), we should pick the m tasks 
    with the smallest time requirements. Any solution that picks a set of m tasks 
    containing a larger task instead of one of the m smallest tasks can be 
    transformed into a solution with the m smallest tasks without increasing 
    the total time spent. 
    
    Among any chosen set of m tasks, to minimize the time spent from the budget D, 
    we should use our K energy drinks on the K tasks with the largest time 
    requirements within that set. 
    
    Let j be the number of tasks we pay for using the budget D. If we complete 
    m tasks total, and use K energy drinks, we pay for j = max(0, m - K) tasks.
    To maximize m, we simply maximize j. This is achieved by picking tasks 
    starting from the smallest until the budget D is exhausted. 
    The maximum total tasks will then be j_max + K, capped at the total N.
    """
    global input_iter
    try:
        # Reading N (number of tasks), K (energy drinks), D (time budget)
        line = next(input_iter)
        N = int(line)
        K = int(next(input_iter))
        D = int(next(input_iter))
        
        # Reading task requirements using list comprehension for performance
        tasks = [int(next(input_iter)) for _ in range(N)]
    except StopIteration:
        return

    # Sort tasks to ensure we process them in ascending order of time requirements
    tasks.sort()
    
    current_sum = 0
    j_max = 0
    # Greedily pick the smallest tasks that fit within the budget D
    for i in range(N):
        if current_sum + tasks[i] <= D:
            current_sum += tasks[i]
            j_max += 1
        else:
            # Once we can't afford the next smallest task, we've found j_max
            break
    
    # The total tasks we can complete is the j_max tasks we paid for, 
    # plus the K tasks we can complete using energy drinks.
    # We must cap this at N because we cannot complete more tasks than available.
    result = min(N, j_max + K)
    print(result)

if __name__ == '__main__':
    # Standard practice: read all input data into memory once for faster processing
    # in Python, then iterate through the tokens.
    data = sys.stdin.read().split()
    if data:
        input_iter = iter(data)
        try:
            # First token is the number of test cases T
            T_str = next(input_iter)
            T = int(T_str)
            for _ in range(T):
                solve()
        except StopIteration:
            pass
```
