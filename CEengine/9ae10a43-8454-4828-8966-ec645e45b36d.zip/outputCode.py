import sys
import os
import io
import glob

# Global input iterator to be used by solve() for efficient input consumption
input_iter = iter([])

def solve():
    """
    Solves a single test case of the tasks and energy drinks problem.
    The logic follows a greedy approach.
    """
    global input_iter
    try:
        # Reading N (number of tasks), K (energy drinks), D (time budget)
        line = next(input_iter)
        N = int(line)
        K = int(next(input_iter))
        D = int(next(input_iter))
        
        # Reading task requirements
        tasks = [int(next(input_iter)) for _ in range(N)]
    except StopIteration:
        return

    # Sort tasks to ensure we process them in ascending order of time requirements
    tasks.sort()
    
    current_sum = 0
    j_max = 0
    # Greedily pick the smallest tasks that fit within the budget D
    for i in range(N):
        if current_sum + tasks[i] <= D:
            current_sum += tasks[i]
            j_max += 1
        else:
            break
    
    # The total tasks we can complete is the j_max tasks we paid for, 
    # plus the K tasks we can complete using energy drinks.
    result = min(N, j_max + K)
    print(result)

def run_testcases():
    # Ensure output directory exists
    os.makedirs("output", exist_ok=True)
    
    # Discover input files
    input_files = sorted(glob.glob("input/input*.txt"))
    
    for input_filename in input_files:
        # Extract index from filename (e.g., input/input00.txt -> 00)
        base_name = os.path.basename(input_filename)
        index = base_name.replace("input", "").replace(".txt", "")
        
        output_filename = os.path.join("output", f"output{index}.txt")
        error_filename = os.path.join("output", f"output{index}_error.txt")
        
        try:
            # Read input file content
            with open(input_filename, 'r') as f:
                file_content = f.read()
            
            # Redirect stdin and stdout as required
            sys.stdin = io.StringIO(file_content)
            sys.stdout = io.StringIO()
            
            # Solution logic execution
            global input_iter
            data = sys.stdin.read().split()
            if data:
                input_iter = iter(data)
                try:
                    T_str = next(input_iter)
                    T = int(T_str)
                    for _ in range(T):
                        solve()
                except StopIteration:
                    pass
            
            # Capture and save output
            output_data = sys.stdout.getvalue()
            with open(output_filename, 'w') as f:
                f.write(output_data)
                
        except Exception as e:
            # Catch errors per file and write to error file
            with open(error_filename, 'w') as f:
                f.write(str(e))
        finally:
            # Always restore standard streams
            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__

if __name__ == "__main__":
    run_testcases()