
# Problem Statement
In the Kingdom of Hexonia, there are $N$ cities and $M$ existing bidirectional roads. Each city $i$ belongs to a specific culture $C_i$. A culture is said to be 'unified' if all cities belonging to that culture are part of the same connected component (i.e., every city of that culture can reach every other city of the same culture using the existing roads).

Your task is to determine the minimum number of additional bidirectional roads that must be built such that every culture in the kingdom becomes unified. A road can be built between any two cities $u$ and $v$. Note that cultures that consist of only one city are already unified by default.

## Input Format
The first line contains an integer $T$, the number of test cases.

For each test case:
- The first line contains two integers $N$ and $M$, the number of cities and the number of existing roads.
- The second line contains $N$ integers $C_1, C_2, \dots, C_N$ ($1 \le C_i \le N$), representing the culture of city $i$.
- The next $M$ lines each contain two integers $u$ and $v$ ($1 \le u, v \le N$), representing an existing bidirectional road between city $u$ and city $v$.
 
## Output Format
For each test case, output a single integer representing the minimum number of additional roads required to ensure every culture in the kingdom is unified.

## Constraints
1 <= T <= 10,000
1 <= N <= 200,000
0 <= M <= 200,000
1 <= C_i <= N
1 <= u, v <= N
The sum of N across all test cases does not exceed 200,000.
The sum of M across all test cases does not exceed 200,000.

## Sample Input
```
3
3 0
1 1 1
4 1
1 1 2 2
1 3
4 2
1 1 2 2
1 2
3 4
```

## Sample Output
```
2
2
0
```

## Solution
```python
import sys

# The task is to find the minimum number of additional bidirectional roads needed to ensure 
# that every culture is unified (all cities of that culture are in the same connected component).
# 
# Step 1: Find the initial connected components in the graph using the provided roads.
# Step 2: For each culture, identify which of these initial connected components its cities belong to.
# Step 3: To unify a culture, all initial components that contain at least one city of that culture 
#         must be merged together. 
# Step 4: The total number of roads needed is the total number of merges required to satisfy 
#         all cultures' requirements. This is equivalent to finding the connected components 
#         in a "meta-graph" where the nodes are the initial components and edges are required 
#         connections between them.

def find(parent, i):
    """Iterative Union-Find find operation with path compression."""
    root = i
    while parent[root] != root:
        root = parent[root]
    # Path compression
    curr = i
    while parent[curr] != root:
        next_p = parent[curr]
        parent[curr] = root
        curr = next_p
    return root

def union(parent, rank, i, j):
    """Union-Find union by rank operation."""
    root_i = find(parent, i)
    root_j = find(parent, j)
    if root_i != root_j:
        if rank[root_i] < rank[root_j]:
            parent[root_i] = root_j
        elif rank[root_i] > rank[root_j]:
            parent[root_j] = root_i
        else:
            parent[root_j] = root_i
            rank[root_i] += 1
        return True
    return False

def solve():
    # Set recursion limit just in case, although find/union are iterative.
    sys.setrecursionlimit(200005)
    
    # Efficiently read all input components into a list.
    try:
        data = sys.stdin.read().split()
    except EOFError:
        return
        
    if not data:
        return
        
    ptr = 0
    if ptr >= len(data):
        return
    t_cases = int(data[ptr])
    ptr += 1
    
    results = []
    for _ in range(t_cases):
        if ptr >= len(data):
            break
        
        n = int(data[ptr])
        m = int(data[ptr+1])
        ptr += 2
        
        # Cultures are provided as N integers. We keep them as strings to avoid unnecessary int conversion.
        cultures = data[ptr:ptr+n]
        ptr += n
        
        # Initial Union-Find structure to find existing connected components.
        # Nodes are represented by indices 0 to N-1.
        parent1 = list(range(n))
        rank1 = [0] * n
        
        # Process all existing bidirectional roads.
        for _ in range(m):
            u = int(data[ptr]) - 1
            v = int(data[ptr+1]) - 1
            ptr += 2
            union(parent1, rank1, u, v)
            
        # Group cities by culture and their initial component root.
        # This helps identify which components each culture spans across.
        culture_root_pairs = []
        for i in range(n):
            # Find the root of the city's initial component.
            culture_root_pairs.append((cultures[i], find(parent1, i)))
        
        # Sorting allows us to process all cities of the same culture consecutively.
        culture_root_pairs.sort()
        
        # Second Union-Find to track the merging of the initial components.
        # The IDs of initial roots are still between 0 and N-1.
        parent2 = list(range(n))
        rank2 = [0] * n
        roads_added = 0
        
        # Iterate through the sorted list and unify initial components shared by the same culture.
        for i in range(n - 1):
            # If the current city and the next city belong to the same culture:
            if culture_root_pairs[i][0] == culture_root_pairs[i+1][0]:
                root_a = culture_root_pairs[i][1]
                root_b = culture_root_pairs[i+1][1]
                # Merge the initial components in the meta-graph.
                # If they were not already in the same meta-component, increment the road count.
                if union(parent2, rank2, root_a, root_b):
                    roads_added += 1
        
        results.append(str(roads_added))
        
    # Output all collected results, separated by newlines.
    if results:
        sys.stdout.write("\n".join(results) + "\n")

if __name__ == '__main__':
    solve()
```
