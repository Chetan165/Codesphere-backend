import random
import os
import math

os.makedirs("input", exist_ok=True)

# TYPE: sample
# TARGETS: basic correctness
# SUM_N: 11
def generate_input00():
    with open("input/input00.txt", "w") as f:
        f.write("""3
3 0
1 1 1
4 1
1 1 2 2
1 3
4 2
1 1 2 2
1 2
3 4
""")

# TYPE: generic
# TARGETS: correctness on small varied topologies and culture distributions
# SUM_N: ~550 (varies)
def generate_input01():
    random.seed(42)
    T = 20
    lines = [str(T)]
    for _ in range(T):
        n = random.randint(5, 50)
        max_m = min(n * (n - 1) // 2, 200)
        m = random.randint(0, max_m)
        cultures = [random.randint(1, min(10, n)) for _ in range(n)]
        lines.append(f"{n} {m}")
        lines.append(" ".join(map(str, cultures)))
        for _ in range(m):
            u = random.randint(1, n)
            v = random.randint(1, n)
            lines.append(f"{u} {v}")
    with open("input/input01.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

# TYPE: generic
# TARGETS: correctness on medium graphs with diverse densities
# SUM_N: ~5500 (varies)
def generate_input02():
    random.seed(123)
    T = 10
    lines = [str(T)]
    for _ in range(T):
        n = random.randint(100, 1000)
        max_m = min(n * (n - 1) // 2, 5000)
        m = random.randint(0, max_m)
        cultures = [random.randint(1, min(50, n)) for _ in range(n)]
        lines.append(f"{n} {m}")
        lines.append(" ".join(map(str, cultures)))
        for _ in range(m):
            u = random.randint(1, n)
            v = random.randint(1, n)
            lines.append(f"{u} {v}")
    with open("input/input02.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

def create_no_edges_many_cultures(n):
    """Deterministic: K=1000 cultures, C_i = ((i-1) mod K) + 1, no edges."""
    K = 1000
    cultures = [((i) % K) + 1 for i in range(n)]
    return cultures, []

# TYPE: large
# TARGETS: BFS/DFS per culture O(N*K) with K=1000, N=200000
# SUM_N: 200000
def generate_input03():
    n = 200000
    cultures, edges = create_no_edges_many_cultures(n)
    m = 0
    with open("input/input03.txt", "w") as f:
        f.write(f"1\n")
        f.write(f"{n} {m}\n")
        f.write(" ".join(map(str, cultures)) + "\n")

def create_broken_chain_alternating(n):
    """Chain with edges removed every 10th position, alternating 2 cultures."""
    cultures = [((i) % 2) + 1 for i in range(n)]
    edges = []
    for i in range(1, n):
        # i is 1-indexed edge from node i to node i+1
        # skip when i (1-based) is a multiple of 10
        if i % 10 != 0:
            edges.append((i, i + 1))
    return cultures, edges

# TYPE: large
# TARGETS: Deep chain DSU path compression, cross-culture merge interactions
# SUM_N: 200000
def generate_input04():
    n = 200000
    cultures, edges = create_broken_chain_alternating(n)
    m = len(edges)
    with open("input/input04.txt", "w") as f:
        f.write(f"1\n")
        f.write(f"{n} {m}\n")
        f.write(" ".join(map(str, cultures)) + "\n")
        for u, v in edges:
            f.write(f"{u} {v}\n")

# TYPE: edge
# TARGETS: Off-by-one, empty graph, self-loops, single node
# SUM_N: 8
def generate_input05():
    lines = []
    # 4 test cases
    lines.append("4")
    
    # single_node: N=1, M=0, C=[1]
    lines.append("1 0")
    lines.append("1")
    
    # two_nodes_same_culture_no_edge: N=2, M=0, C=[1,1]
    lines.append("2 0")
    lines.append("1 1")
    
    # self_loop: N=3, M=2, C=[1,1,2], edges (1,1) and (2,2)
    lines.append("3 2")
    lines.append("1 1 2")
    lines.append("1 1")
    lines.append("2 2")
    
    # two_nodes_same_culture_with_edge: N=2, M=1, C=[1,1], edge (1,2)
    lines.append("2 1")
    lines.append("1 1")
    lines.append("1 2")
    
    with open("input/input05.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

# TYPE: edge
# TARGETS: All distinct cultures, all same culture, duplicate edges
# SUM_N: 24
def generate_input06():
    lines = []
    # 4 test cases
    lines.append("4")
    
    # all_distinct_cultures_no_edges: N=10, M=0, C=[1..10]
    lines.append("10 0")
    lines.append("1 2 3 4 5 6 7 8 9 10")
    
    # all_same_culture_fully_connected (chain): N=5, M=4, C=[1,1,1,1,1]
    lines.append("5 4")
    lines.append("1 1 1 1 1")
    lines.append("1 2")
    lines.append("2 3")
    lines.append("3 4")
    lines.append("4 5")
    
    # all_same_culture_fully_disconnected: N=5, M=0, C=[1,1,1,1,1]
    lines.append("5 0")
    lines.append("1 1 1 1 1")
    
    # duplicate_edges: N=4, M=3, C=[1,1,2,2], edges (1,2),(1,2),(3,4)
    lines.append("4 3")
    lines.append("1 1 2 2")
    lines.append("1 2")
    lines.append("1 2")
    lines.append("3 4")
    
    with open("input/input06.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

# TYPE: edge
# TARGETS: Max T overhead, sparse culture IDs, culture ID = N
# SUM_N: 10011
def generate_input07():
    lines = []
    # We have 3 named cases but first is 10000 test cases, then 2 more
    # Total T = 10000 + 2 = 10002 ... wait, let me re-read.
    # The plan says: max_T_single_nodes (T=10000), sparse_culture_ids (1 test), culture_id_equals_N (1 test)
    # But T is the first line of the file. We need to combine them.
    # Actually, looking at the plan more carefully, these are separate "cases" within one file.
    # We'll make it T = 10002 to include all.
    
    T = 10000 + 1 + 1
    lines.append(str(T))
    
    # max_T_single_nodes: 10000 test cases each N=1, M=0, C=[1]
    for _ in range(10000):
        lines.append("1 0")
        lines.append("1")
    
    # sparse_culture_ids: N=5, M=0, C=[5,5,3,3,1]
    lines.append("5 0")
    lines.append("5 5 3 3 1")
    
    # culture_id_equals_N: N=6, M=0, C=[6,6,6,6,6,6]
    lines.append("6 0")
    lines.append("6 6 6 6 6 6")
    
    with open("input/input07.txt", "w") as f:
        f.write("\n".join(lines) + "\n")

def create_many_star_tests():
    """200 test cases with star topology and cultures spread across connected/disconnected nodes."""
    test_cases = []
    for t in range(200):
        n = 1000 - t  # n_values from 1000 down to 801
        m_edges = min(500, n - 1)
        # Star: edges (1, i) for i=2..m_edges+1
        edges = []
        for i in range(2, m_edges + 2):
            if i <= n:
                edges.append((1, i))
        m = len(edges)
        # Cultures: C_i = ((i-1) mod 50) + 1
        cultures = [((i) % 50) + 1 for i in range(n)]
        test_cases.append((n, m, cultures, edges))
    return test_cases

# TYPE: large
# TARGETS: Per-test DSU reset overhead, BFS per culture with star topology
# SUM_N: 180100
def generate_input08():
    test_cases = create_many_star_tests()
    T = len(test_cases)
    with open("input/input08.txt", "w") as f:
        f.write(f"{T}\n")
        for n, m, cultures, edges in test_cases:
            f.write(f"{n} {m}\n")
            f.write(" ".join(map(str, cultures)) + "\n")
            for u, v in edges:
                f.write(f"{u} {v}\n")

def create_max_merges_isolated(n):
    """N nodes, no edges, culture ceil(i/2) so each culture has 2 nodes in separate components."""
    cultures = [((i) // 2) + 1 for i in range(n)]
    # culture for 0-indexed i: i//2 + 1
    # i=0 -> 1, i=1 -> 1, i=2 -> 2, i=3 -> 2, etc.
    return cultures, []

# TYPE: large
# TARGETS: Naive O(N) scan per culture with 100000 cultures, total O(N * num_cultures)
# SUM_N: 200000
def generate_input09():
    n = 200000
    cultures, edges = create_max_merges_isolated(n)
    m = 0
    with open("input/input09.txt", "w") as f:
        f.write(f"1\n")
        f.write(f"{n} {m}\n")
        f.write(" ".join(map(str, cultures)) + "\n")

if __name__ == "__main__":
    generate_input00()
    generate_input01()
    generate_input02()
    generate_input03()
    generate_input04()
    generate_input05()
    generate_input06()
    generate_input07()
    generate_input08()
    generate_input09()