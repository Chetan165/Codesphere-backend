import sys
import os
import io
import glob


def find(parent, i):
    root = i
    while parent[root] != root:
        root = parent[root]
    curr = i
    while parent[curr] != root:
        next_p = parent[curr]
        parent[curr] = root
        curr = next_p
    return root


def union(parent, rank, i, j):
    root_i = find(parent, i)
    root_j = find(parent, j)
    if root_i != root_j:
        if rank[root_i] < rank[root_j]:
            parent[root_i] = root_j
        elif rank[root_i] > rank[root_j]:
            parent[root_j] = root_i
        else:
            parent[root_j] = root_i
            rank[root_i] += 1
        return True
    return False


def solve():
    sys.setrecursionlimit(200005)

    try:
        data = sys.stdin.read().split()
    except EOFError:
        return

    if not data:
        return

    ptr = 0
    if ptr >= len(data):
        return
    t_cases = int(data[ptr])
    ptr += 1

    results = []
    for _ in range(t_cases):
        if ptr >= len(data):
            break

        n = int(data[ptr])
        m = int(data[ptr + 1])
        ptr += 2

        cultures = data[ptr:ptr + n]
        ptr += n

        parent1 = list(range(n))
        rank1 = [0] * n

        for _ in range(m):
            u = int(data[ptr]) - 1
            v = int(data[ptr + 1]) - 1
            ptr += 2
            union(parent1, rank1, u, v)

        culture_root_pairs = []
        for i in range(n):
            culture_root_pairs.append((cultures[i], find(parent1, i)))

        culture_root_pairs.sort()

        parent2 = list(range(n))
        rank2 = [0] * n
        roads_added = 0

        for i in range(n - 1):
            if culture_root_pairs[i][0] == culture_root_pairs[i + 1][0]:
                root_a = culture_root_pairs[i][1]
                root_b = culture_root_pairs[i + 1][1]
                if union(parent2, rank2, root_a, root_b):
                    roads_added += 1

        results.append(str(roads_added))

    if results:
        sys.stdout.write("\n".join(results) + "\n")


def main():
    os.makedirs("output", exist_ok=True)

    input_files = sorted(glob.glob("input/input*.txt"))

    for input_filename in input_files:
        basename = os.path.basename(input_filename)
        index = basename.replace("input", "").replace(".txt", "")
        output_filename = os.path.join("output", f"output{index}.txt")
        error_filename = os.path.join("output", f"output{index}_error.txt")

        try:
            with open(input_filename, 'r') as f:
                file_content = f.read()

            sys.stdin = io.StringIO(file_content)
            sys.stdout = io.StringIO()

            solve()

            output = sys.stdout.getvalue()

            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__

            with open(output_filename, 'w') as f:
                f.write(output)

            print(f"Processed {input_filename} -> {output_filename}")

        except Exception as e:
            sys.stdin = sys.__stdin__
            sys.stdout = sys.__stdout__

            with open(error_filename, 'w') as f:
                f.write(str(e))

            print(f"Error processing {input_filename}: {e}")


if __name__ == '__main__':
    main()