
# Problem Statement
You're managing a critical rescue mission where `N` people need to be evacuated from a sinking ship. You have an unlimited supply of rescue pods, each with a fixed weight `limit`. Each pod can carry at most two people. To minimize the total number of pods used and thus streamline the rescue, you must assign people efficiently. If a pod carries two people, their combined weight cannot exceed the `limit`. If a pod carries only one person, that person's weight must not exceed the `limit` (which is always true if they are to be saved).

Given an array `weights`, where `weights[i]` is the weight of the i-th person, and an integer `limit`, determine the minimum number of rescue pods required to save all `N` people.

## Input Format
The first line contains an integer `N`, the number of people.
The second line contains `N` space-separated integers, representing the `weights` of the people.
The third line contains an integer `limit`, the maximum weight capacity of a single rescue pod.

## Output Format
A single integer representing the minimum number of rescue pods required.

## Constraints
*   `1 <= N <= 5 * 10^4`
*   `1 <= weights[i] <= limit`
*   `1 <= limit <= 3 * 10^4`
*   Each `weights[i]` is an integer.

## Sample Input
```
4
3 2 2 1
3
```

## Sample Output
```
3
```

## Solution
```python
def minRescuePods(weights: list[int], limit: int) -> int:
    """
    Calculates the minimum number of rescue pods required to save all people.
    Each pod can carry at most two people, with a total weight limit.
    
    Args:
        weights: A list of integers representing the weights of the people.
        limit: An integer representing the maximum weight capacity of a rescue pod.
        
    Returns:
        The minimum number of rescue pods.
    """
    weights.sort()  # Sort the weights in ascending order (O(N log N))
    
    pods = 0
    left = 0          # Pointer for the lightest person
    right = len(weights) - 1 # Pointer for the heaviest person
    
    # Use two pointers to pair people (O(N))
    while left <= right:
        # Each iteration saves at least one person (the heaviest person at 'right')
        pods += 1
        
        # Try to pair the heaviest person with the lightest
        # If their combined weight is within the limit, both are saved in one pod
        if weights[left] + weights[right] <= limit:
            left += 1 # The lightest person is now saved, move to the next lightest
        
        right -= 1 # The heaviest person is always saved (either alone or with 'left'),
                   # move to the next heaviest person
            
    return pods

# Example usage (for competitive programming platforms, input might be read from stdin)
if __name__ == '__main__':
    N = int(input())
    weights = list(map(int, input().split()))
    limit = int(input())
    
    result = minRescuePods(weights, limit)
    print(result)

```
